import { 
  Product, InsertProduct, UpdateProduct,
  Competitor, InsertCompetitor,
  CompetitorPrice, InsertCompetitorPrice,
  PriceHistory, InsertPriceHistory,
  ProductWithCompetitorPrices, PriceTrend,
  defaultProducts, defaultCompetitors, defaultCompetitorPrices
} from "@shared/schema";

// Storage interface
export interface IStorage {
  // Product methods
  getProducts(): Promise<Product[]>;
  getProduct(id: number): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: number, product: UpdateProduct): Promise<Product | undefined>;
  deleteProduct(id: number): Promise<boolean>;
  getProductsWithCompetitorPrices(): Promise<ProductWithCompetitorPrices[]>;
  
  // Competitor methods
  getCompetitors(): Promise<Competitor[]>;
  getCompetitor(id: number): Promise<Competitor | undefined>;
  createCompetitor(competitor: InsertCompetitor): Promise<Competitor>;
  
  // Competitor Price methods
  getCompetitorPrices(productId: number): Promise<CompetitorPrice[]>;
  createCompetitorPrice(competitorPrice: InsertCompetitorPrice): Promise<CompetitorPrice>;
  updateCompetitorPrice(id: number, price: number): Promise<CompetitorPrice | undefined>;
  
  // Price History methods
  getPriceHistory(productId: number, days?: number): Promise<PriceHistory[]>;
  createPriceHistory(priceHistory: InsertPriceHistory): Promise<PriceHistory>;
  
  // Analytics methods
  getPriceTrends(productId: number, days?: number): Promise<PriceTrend[]>;
  optimizeProductPrice(productId: number): Promise<Product | undefined>;
  optimizeAllPrices(): Promise<Product[]>;
}

// In-memory storage implementation
export class MemStorage implements IStorage {
  private products: Map<number, Product>;
  private competitors: Map<number, Competitor>;
  private competitorPrices: Map<number, CompetitorPrice>;
  private priceHistory: Map<number, PriceHistory>;
  private currentProductId: number;
  private currentCompetitorId: number;
  private currentCompetitorPriceId: number;
  private currentPriceHistoryId: number;

  constructor() {
    this.products = new Map();
    this.competitors = new Map();
    this.competitorPrices = new Map();
    this.priceHistory = new Map();
    
    this.currentProductId = 1;
    this.currentCompetitorId = 1;
    this.currentCompetitorPriceId = 1;
    this.currentPriceHistoryId = 1;
    
    // Initialize with default data
    this.initializeDefaultData();
  }

  private initializeDefaultData() {
    // Add default products
    for (const product of defaultProducts) {
      const newProduct: Product = {
        ...product,
        suggestedPrice: null,
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      this.products.set(product.id, newProduct);
      this.currentProductId = Math.max(this.currentProductId, product.id + 1);
    }

    // Add default competitors
    for (const competitor of defaultCompetitors) {
      const newCompetitor: Competitor = {
        ...competitor,
        createdAt: new Date(),
      };
      this.competitors.set(competitor.id, newCompetitor);
      this.currentCompetitorId = Math.max(this.currentCompetitorId, competitor.id + 1);
    }

    // Add default competitor prices
    for (const cp of defaultCompetitorPrices) {
      const newCompetitorPrice: CompetitorPrice = {
        id: this.currentCompetitorPriceId++,
        ...cp,
        timestamp: new Date(),
      };
      this.competitorPrices.set(newCompetitorPrice.id, newCompetitorPrice);
    }

    // Create initial price history (last 7 days)
    for (const product of defaultProducts) {
      const today = new Date();
      for (let i = 6; i >= 0; i--) {
        const date = new Date(today);
        date.setDate(date.getDate() - i);
        
        // Some small random price fluctuations for history
        const basePrice = product.currentPrice;
        const randomFluctuation = Math.random() * 10 - 5; // Between -5 and +5
        const historicalPrice = Math.round((basePrice + randomFluctuation) * 100) / 100;
        
        const priceHistoryEntry: PriceHistory = {
          id: this.currentPriceHistoryId++,
          productId: product.id,
          price: historicalPrice,
          timestamp: date,
        };
        this.priceHistory.set(priceHistoryEntry.id, priceHistoryEntry);
      }
    }

    // Calculate initial suggested prices
    this.optimizeAllPrices();
  }

  // Product methods
  async getProducts(): Promise<Product[]> {
    return Array.from(this.products.values());
  }

  async getProduct(id: number): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async createProduct(productData: InsertProduct): Promise<Product> {
    const id = this.currentProductId++;
    const product: Product = {
      id,
      ...productData,
      suggestedPrice: null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.products.set(id, product);
    return product;
  }

  async updateProduct(id: number, productData: UpdateProduct): Promise<Product | undefined> {
    const product = this.products.get(id);
    if (!product) return undefined;

    const updatedProduct: Product = {
      ...product,
      ...productData,
      updatedAt: new Date(),
    };
    this.products.set(id, updatedProduct);
    
    // Add price history entry if price changed
    if (productData.currentPrice !== undefined && productData.currentPrice !== product.currentPrice) {
      await this.createPriceHistory({
        productId: id,
        price: productData.currentPrice,
      });
    }
    
    return updatedProduct;
  }

  async deleteProduct(id: number): Promise<boolean> {
    return this.products.delete(id);
  }

  async getProductsWithCompetitorPrices(): Promise<ProductWithCompetitorPrices[]> {
    const products = await this.getProducts();
    const competitors = await this.getCompetitors();
    
    return Promise.all(products.map(async (product) => {
      const competitorPrices = Array.from(this.competitorPrices.values())
        .filter(cp => cp.productId === product.id)
        .map(cp => {
          const competitor = competitors.find(c => c.id === cp.competitorId);
          return {
            competitorId: cp.competitorId,
            competitorName: competitor?.name || 'Unknown',
            price: cp.price,
          };
        });
      
      return {
        ...product,
        competitorPrices,
      };
    }));
  }

  // Competitor methods
  async getCompetitors(): Promise<Competitor[]> {
    return Array.from(this.competitors.values());
  }

  async getCompetitor(id: number): Promise<Competitor | undefined> {
    return this.competitors.get(id);
  }

  async createCompetitor(competitorData: InsertCompetitor): Promise<Competitor> {
    const id = this.currentCompetitorId++;
    const competitor: Competitor = {
      id,
      ...competitorData,
      createdAt: new Date(),
    };
    this.competitors.set(id, competitor);
    return competitor;
  }

  // Competitor Price methods
  async getCompetitorPrices(productId: number): Promise<CompetitorPrice[]> {
    return Array.from(this.competitorPrices.values())
      .filter(cp => cp.productId === productId);
  }

  async createCompetitorPrice(competitorPriceData: InsertCompetitorPrice): Promise<CompetitorPrice> {
    const id = this.currentCompetitorPriceId++;
    const competitorPrice: CompetitorPrice = {
      id,
      ...competitorPriceData,
      timestamp: new Date(),
    };
    this.competitorPrices.set(id, competitorPrice);
    return competitorPrice;
  }

  async updateCompetitorPrice(id: number, price: number): Promise<CompetitorPrice | undefined> {
    const competitorPrice = this.competitorPrices.get(id);
    if (!competitorPrice) return undefined;

    const updatedCompetitorPrice: CompetitorPrice = {
      ...competitorPrice,
      price,
      timestamp: new Date(),
    };
    this.competitorPrices.set(id, updatedCompetitorPrice);
    return updatedCompetitorPrice;
  }

  // Price History methods
  async getPriceHistory(productId: number, days = 7): Promise<PriceHistory[]> {
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - days);
    
    return Array.from(this.priceHistory.values())
      .filter(ph => ph.productId === productId && ph.timestamp >= cutoffDate)
      .sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime());
  }

  async createPriceHistory(priceHistoryData: InsertPriceHistory): Promise<PriceHistory> {
    const id = this.currentPriceHistoryId++;
    const priceHistory: PriceHistory = {
      id,
      ...priceHistoryData,
      timestamp: new Date(),
    };
    this.priceHistory.set(id, priceHistory);
    return priceHistory;
  }

  // Analytics methods
  async getPriceTrends(productId: number, days = 7): Promise<PriceTrend[]> {
    const priceHistory = await this.getPriceHistory(productId, days);
    const competitors = await this.getCompetitors();
    
    // Get unique dates from price history
    const dates = [...new Set(priceHistory.map(ph => 
      ph.timestamp.toISOString().split('T')[0]
    ))];
    
    // For each date, get the price from our price history and from competitors
    return Promise.all(dates.map(async (date) => {
      const dateObj = new Date(date);
      const nextDay = new Date(dateObj);
      nextDay.setDate(nextDay.getDate() + 1);
      
      // Get our price for this date
      const ourPriceEntry = priceHistory
        .filter(ph => ph.timestamp >= dateObj && ph.timestamp < nextDay)
        .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())[0];
      
      // Get competitor prices
      const competitorPriceEntries = Array.from(this.competitorPrices.values())
        .filter(cp => 
          cp.productId === productId && 
          cp.timestamp >= dateObj && 
          cp.timestamp < nextDay
        );
      
      const competitorPrices = competitorPriceEntries.map(cp => {
        const competitor = competitors.find(c => c.id === cp.competitorId);
        return {
          competitorId: cp.competitorId,
          competitorName: competitor?.name || 'Unknown',
          price: cp.price,
        };
      });
      
      return {
        date,
        yourPrice: ourPriceEntry ? ourPriceEntry.price : 0,
        competitorPrices,
      };
    }));
  }

  async optimizeProductPrice(productId: number): Promise<Product | undefined> {
    const product = await this.getProduct(productId);
    if (!product) return undefined;
    
    const competitorPrices = await this.getCompetitorPrices(productId);
    
    if (competitorPrices.length === 0) {
      return product; // No competitor prices to optimize against
    }
    
    // Calculate average competitor price
    const avgCompetitorPrice = competitorPrices.reduce((sum, cp) => sum + cp.price, 0) / competitorPrices.length;
    
    // Set suggested price at 5% below average competitor price
    // but never go below cost (assumed to be 70% of current price as a simple heuristic)
    const estimatedCost = product.currentPrice * 0.7;
    let suggestedPrice = avgCompetitorPrice * 0.95;
    
    // Ensure we maintain at least 10% margin over estimated cost
    const minimumPrice = estimatedCost * 1.1;
    if (suggestedPrice < minimumPrice) {
      suggestedPrice = minimumPrice;
    }
    
    // Round to 2 decimal places
    suggestedPrice = Math.round(suggestedPrice * 100) / 100;
    
    // Update the product with the suggested price
    const updatedProduct = await this.updateProduct(productId, { 
      suggestedPrice,
    });
    
    return updatedProduct;
  }

  async optimizeAllPrices(): Promise<Product[]> {
    const products = await this.getProducts();
    const optimizedProducts: Product[] = [];
    
    for (const product of products) {
      const optimizedProduct = await this.optimizeProductPrice(product.id);
      if (optimizedProduct) {
        optimizedProducts.push(optimizedProduct);
      }
    }
    
    return optimizedProducts;
  }
}

export const storage = new MemStorage();
