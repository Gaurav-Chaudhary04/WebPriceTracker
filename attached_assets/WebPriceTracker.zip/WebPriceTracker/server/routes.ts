import express, { type Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import axios from "axios";
import { RealTimePricingService } from "./services/realTimePricingService";
import { 
  insertProductSchema, 
  updateProductSchema,
  insertCompetitorPriceSchema,
  insertCompetitorSchema
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Create API router
  const apiRouter = express.Router();
  
  // Product endpoints
  apiRouter.get('/products', async (req: Request, res: Response) => {
    try {
      const products = await storage.getProducts();
      res.json(products);
    } catch (error) {
      res.status(500).json({ error: `Failed to fetch products: ${error}` });
    }
  });
  
  apiRouter.get('/products/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const product = await storage.getProduct(id);
      
      if (!product) {
        return res.status(404).json({ error: `Product with ID ${id} not found` });
      }
      
      res.json(product);
    } catch (error) {
      res.status(500).json({ error: `Failed to fetch product: ${error}` });
    }
  });
  
  apiRouter.post('/products', async (req: Request, res: Response) => {
    try {
      const validatedData = insertProductSchema.parse(req.body);
      const product = await storage.createProduct(validatedData);
      res.status(201).json(product);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: `Failed to create product: ${error}` });
    }
  });
  
  apiRouter.put('/products/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = updateProductSchema.parse(req.body);
      const product = await storage.updateProduct(id, validatedData);
      
      if (!product) {
        return res.status(404).json({ error: `Product with ID ${id} not found` });
      }
      
      res.json(product);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: `Failed to update product: ${error}` });
    }
  });
  
  apiRouter.delete('/products/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteProduct(id);
      
      if (!success) {
        return res.status(404).json({ error: `Product with ID ${id} not found` });
      }
      
      res.status(204).end();
    } catch (error) {
      res.status(500).json({ error: `Failed to delete product: ${error}` });
    }
  });
  
  // Product with competitor prices endpoint
  apiRouter.get('/products-with-prices', async (req: Request, res: Response) => {
    try {
      const products = await storage.getProductsWithCompetitorPrices();
      res.json(products);
    } catch (error) {
      res.status(500).json({ error: `Failed to fetch products with prices: ${error}` });
    }
  });
  
  // Competitor endpoints
  apiRouter.get('/competitors', async (req: Request, res: Response) => {
    try {
      const competitors = await storage.getCompetitors();
      res.json(competitors);
    } catch (error) {
      res.status(500).json({ error: `Failed to fetch competitors: ${error}` });
    }
  });
  
  apiRouter.post('/competitors', async (req: Request, res: Response) => {
    try {
      const validatedData = insertCompetitorSchema.parse(req.body);
      const competitor = await storage.createCompetitor(validatedData);
      res.status(201).json(competitor);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: `Failed to create competitor: ${error}` });
    }
  });
  
  // Competitor Price endpoints
  apiRouter.get('/competitor-prices/:productId', async (req: Request, res: Response) => {
    try {
      const productId = parseInt(req.params.productId);
      const competitorPrices = await storage.getCompetitorPrices(productId);
      res.json(competitorPrices);
    } catch (error) {
      res.status(500).json({ error: `Failed to fetch competitor prices: ${error}` });
    }
  });
  
  apiRouter.post('/competitor-prices', async (req: Request, res: Response) => {
    try {
      const validatedData = insertCompetitorPriceSchema.parse(req.body);
      const competitorPrice = await storage.createCompetitorPrice(validatedData);
      res.status(201).json(competitorPrice);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: `Failed to create competitor price: ${error}` });
    }
  });
  
  // Price History endpoints
  apiRouter.get('/price-history/:productId', async (req: Request, res: Response) => {
    try {
      const productId = parseInt(req.params.productId);
      const days = req.query.days ? parseInt(req.query.days as string) : 7;
      const priceHistory = await storage.getPriceHistory(productId, days);
      res.json(priceHistory);
    } catch (error) {
      res.status(500).json({ error: `Failed to fetch price history: ${error}` });
    }
  });
  
  // Price Trends endpoints
  apiRouter.get('/price-trends/:productId', async (req: Request, res: Response) => {
    try {
      const productId = parseInt(req.params.productId);
      const days = req.query.days ? parseInt(req.query.days as string) : 7;
      const priceTrends = await storage.getPriceTrends(productId, days);
      res.json(priceTrends);
    } catch (error) {
      res.status(500).json({ error: `Failed to fetch price trends: ${error}` });
    }
  });
  
  // Price Optimization endpoints
  apiRouter.post('/optimize-prices', async (req: Request, res: Response) => {
    try {
      const products = await storage.optimizeAllPrices();
      res.json(products);
    } catch (error) {
      res.status(500).json({ error: `Failed to optimize prices: ${error}` });
    }
  });
  
  apiRouter.post('/optimize-price/:productId', async (req: Request, res: Response) => {
    try {
      const productId = parseInt(req.params.productId);
      const product = await storage.optimizeProductPrice(productId);
      
      if (!product) {
        return res.status(404).json({ error: `Product with ID ${productId} not found` });
      }
      
      res.json(product);
    } catch (error) {
      res.status(500).json({ error: `Failed to optimize price: ${error}` });
    }
  });
  
  // Apply suggested price endpoint
  apiRouter.post('/apply-suggested-price/:productId', async (req: Request, res: Response) => {
    try {
      const productId = parseInt(req.params.productId);
      const product = await storage.getProduct(productId);
      
      if (!product) {
        return res.status(404).json({ error: `Product with ID ${productId} not found` });
      }
      
      if (!product.suggestedPrice) {
        return res.status(400).json({ error: `No suggested price available for product with ID ${productId}` });
      }
      
      const updatedProduct = await storage.updateProduct(productId, {
        currentPrice: product.suggestedPrice,
      });
      
      // Add to price history
      await storage.createPriceHistory({
        productId,
        price: product.suggestedPrice,
      });
      
      res.json(updatedProduct);
    } catch (error) {
      res.status(500).json({ error: `Failed to apply suggested price: ${error}` });
    }
  });
  
  // Apply all suggested prices endpoint
  apiRouter.post('/apply-all-suggested-prices', async (req: Request, res: Response) => {
    try {
      const products = await storage.getProducts();
      const updatedProducts = [];
      
      for (const product of products) {
        if (product.suggestedPrice) {
          const updatedProduct = await storage.updateProduct(product.id, {
            currentPrice: product.suggestedPrice,
          });
          
          // Add to price history
          await storage.createPriceHistory({
            productId: product.id,
            price: product.suggestedPrice,
          });
          
          if (updatedProduct) {
            updatedProducts.push(updatedProduct);
          }
        }
      }
      
      res.json(updatedProducts);
    } catch (error) {
      res.status(500).json({ error: `Failed to apply all suggested prices: ${error}` });
    }
  });
  
  // Real-time pricing endpoints
  apiRouter.post('/fetch-competitor-prices/:productId', async (req: Request, res: Response) => {
    try {
      const productId = parseInt(req.params.productId);
      const product = await storage.getProduct(productId);
      
      if (!product) {
        return res.status(404).json({ error: `Product with ID ${productId} not found` });
      }
      
      // Fetch real-time prices for this product
      const competitorPrices = await RealTimePricingService.fetchRealTimeProductPrices(productId, product);
      
      // Save the fetched prices to the database
      const savedPrices = [];
      for (const priceData of competitorPrices) {
        // Save competitor price
        const competitorPrice = await storage.createCompetitorPrice({
          productId: priceData.productId,
          competitorId: priceData.competitorId,
          price: priceData.price,
        });
        
        // Add to price history
        await storage.createPriceHistory({
          productId: priceData.productId,
          competitorId: priceData.competitorId,
          price: priceData.price,
        });
        
        savedPrices.push(competitorPrice);
      }
      
      res.json(savedPrices);
    } catch (error) {
      res.status(500).json({ error: `Failed to fetch competitor prices: ${error}` });
    }
  });
  
  apiRouter.post('/update-all-competitor-prices', async (req: Request, res: Response) => {
    try {
      await RealTimePricingService.updateAllPrices();
      
      const products = await storage.getProductsWithCompetitorPrices();
      res.json(products);
    } catch (error) {
      res.status(500).json({ error: `Failed to update all competitor prices: ${error}` });
    }
  });
  
  // API configuration endpoints
  apiRouter.post('/settings/api', async (req: Request, res: Response) => {
    try {
      // Store API keys in environment variables 
      // In a real production app, these would be stored securely
      if (req.body.apiKey) {
        process.env.PRICING_API_KEY = req.body.apiKey;
      }
      
      if (req.body.competitorApiEndpoint) {
        process.env.PRICE_API_ENDPOINT = req.body.competitorApiEndpoint;
      }
      
      res.json({ success: true, message: "API settings updated successfully" });
    } catch (error) {
      res.status(500).json({ error: `Failed to update API settings: ${error}` });
    }
  });
  
  apiRouter.post('/settings/general', async (req: Request, res: Response) => {
    try {
      // In a real app, these would be stored in a database
      // For demo purposes, we'll just return success
      res.json({ success: true, message: "General settings updated successfully", settings: req.body });
    } catch (error) {
      res.status(500).json({ error: `Failed to update general settings: ${error}` });
    }
  });
  
  // Test PriceAPI integration
  apiRouter.get('/test-price-api', async (req: Request, res: Response) => {
    try {
      const priceApiKey = process.env.PRICE_API_KEY;
      
      if (!priceApiKey) {
        return res.status(400).json({ error: 'PriceAPI key is not configured' });
      }
      
      // Make a simple request to PriceAPI to validate the key
      const response = await axios.get('https://api.priceapi.com/v2/jobs', {
        params: {
          token: priceApiKey
        }
      });
      
      return res.json({
        status: 'Success',
        message: 'PriceAPI connection successful',
        apiVersion: response.data?.apiVersion || 'unknown',
        jobCount: response.data?.jobs?.length || 0
      });
    } catch (error) {
      console.error('Error testing PriceAPI:', error);
      return res.status(500).json({
        status: 'Error',
        message: 'Failed to connect to PriceAPI',
        error: error.message,
        response: error.response?.data || null
      });
    }
  });
  
  // Fetch real product data from PriceAPI
  apiRouter.get('/fetch-real-products', async (req: Request, res: Response) => {
    try {
      const priceApiKey = process.env.PRICE_API_KEY;
      
      if (!priceApiKey) {
        return res.status(400).json({ error: 'PriceAPI key is not configured' });
      }
      
      console.log('Fetching real products from PriceAPI...');
      
      // FIXED: Using the correct topic 'search_results' and including a query for electronics
      // This follows PriceAPI's requirements as documented in the error message
      const createResponse = await axios.post('https://api.priceapi.com/v2/jobs', {
        token: priceApiKey,
        source: 'amazon',  // Using Amazon as the data source
        country: 'us',
        topic: 'search_results',  // FIXED: Using a valid topic parameter
        query: 'electronics',     // ADDED: Query parameter with the search term
        key: 'term',
        max_age: 86400 // Accept results up to 24 hours old for faster response
      });
      
      console.log('Create job response:', createResponse.status);
      
      if (createResponse.status !== 200) {
        return res.status(500).json({ 
          error: 'Failed to create search job', 
          status: createResponse.status,
          details: createResponse.data || {}
        });
      }
      
      const jobId = createResponse.data?.id;
      
      if (!jobId) {
        return res.status(500).json({ error: 'No job ID returned from API' });
      }
      
      // Poll for job completion
      let jobStatus = 'created';
      let attempts = 0;
      let jobResult = null;
      
      while (jobStatus !== 'finished' && jobStatus !== 'failed' && attempts < 15) {
        attempts++;
        
        // Wait a bit between polling attempts
        await new Promise(resolve => setTimeout(resolve, 1500));
        
        // Check job status
        const statusResponse = await axios.get(`https://api.priceapi.com/v2/jobs/${jobId}`, {
          params: { token: priceApiKey }
        });
        
        jobStatus = statusResponse.data?.status;
        console.log(`Job status (attempt ${attempts}): ${jobStatus}`);
        
        if (jobStatus === 'finished') {
          jobResult = statusResponse.data?.result;
        } else if (jobStatus === 'failed') {
          // If job failed, return specific error information
          return res.status(500).json({
            status: 'Error',
            message: 'PriceAPI job failed to complete',
            error: statusResponse.data?.error || 'Unknown error',
            jobId: jobId
          });
        }
      }
      
      if (jobStatus !== 'finished' || !jobResult) {
        return res.status(500).json({ 
          error: 'Job did not complete successfully', 
          status: jobStatus 
        });
      }
      
      // Process the results
      const products = jobResult.products || [];
      
      const formattedProducts = products.map((p: any) => {
        // Extract category from product data if available
        let category = 'Electronics';
        if (p.categories && p.categories.length > 0) {
          category = p.categories.map((c: any) => c.name).join(' / ');
        }
        
        // Extract price from offers if available
        let price = 0;
        if (p.offers && p.offers.length > 0 && p.offers[0].price) {
          price = parseFloat(p.offers[0].price.value);
        }
        
        return {
          name: p.name || 'Unknown Product',
          description: p.description || 'No description available',
          category: category,
          currentPrice: price || 99.99, // Default price if none found
          sku: p.id || `SKU-${Math.floor(Math.random() * 100000)}`,
          imageUrl: p.image || null
        };
      });
      
      // If no products found
      if (formattedProducts.length === 0) {
        console.warn('No products found from PriceAPI search results');
        return res.status(404).json({
          status: 'Error',
          message: 'No products found from PriceAPI search results',
          error: 'Empty result set',
          jobId: jobId
        });
      }
      
      return res.json({
        status: 'Success',
        message: `Found ${formattedProducts.length} products`,
        products: formattedProducts
      });
    } catch (error: any) {
      console.error('Error fetching real products:', error);
      
      // Create a detailed error response
      const errorResponse = {
        status: 'Error',
        message: 'Failed to fetch real products',
        error: error.message,
        response: error.response?.data || null
      };
      
      // If there's a specific API error message, include it
      if (error.response?.data?.comment) {
        errorResponse.message = `API Error: ${error.response.data.comment}`;
      }
      
      // Log the full error details for debugging
      if (error.response?.data) {
        console.error('PriceAPI error details:', JSON.stringify(error.response.data, null, 2));
      }
      
      return res.status(500).json(errorResponse);
    }
  });
  
  // Register API router
  app.use('/api', apiRouter);

  // Create HTTP server
  const httpServer = createServer(app);
  
  return httpServer;
}
