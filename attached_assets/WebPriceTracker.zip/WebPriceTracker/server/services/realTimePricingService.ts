import axios from 'axios';
import { storage } from '../storage';
import { InsertCompetitorPrice, Product, Competitor } from '@shared/schema';

/**
 * Service for fetching real-time pricing data from external APIs
 */
export class RealTimePricingService {
  
  /**
   * Fetch real-time pricing data for a product from multiple sources
   * @param productId - The ID of the product to fetch prices for
   * @param product - The product data
   * @returns Array of competitor prices
   */
  static async fetchRealTimeProductPrices(productId: number, product: Product): Promise<InsertCompetitorPrice[]> {
    try {
      const competitors = await storage.getCompetitors();
      const competitorPrices: InsertCompetitorPrice[] = [];
      
      // API key is optional - if not provided, falls back to simulated data
      const apiKey = process.env.PRICING_API_KEY;
      
      // For each competitor, try to fetch their price for this product
      for (const competitor of competitors) {
        try {
          const price = await this.fetchSingleCompetitorPrice(product, competitor, apiKey);
          if (price) {
            competitorPrices.push({
              productId,
              competitorId: competitor.id,
              price: price.toString(),
              timestamp: new Date(),
            });
          }
        } catch (error) {
          console.error(`Error fetching price from ${competitor.name} for product ${product.name}:`, error);
          // Continue with other competitors even if one fails
        }
      }
      
      return competitorPrices;
    } catch (error) {
      console.error(`Error in fetchRealTimeProductPrices for product ID ${productId}:`, error);
      throw error;
    }
  }
  
  /**
   * Fetch a price from a single competitor
   * @param product - The product to fetch the price for
   * @param competitor - The competitor to fetch price from
   * @param apiKey - Optional API key for real data (if available)
   * @returns The price as a number, or null if not found
   */
  private static async fetchSingleCompetitorPrice(
    product: Product, 
    competitor: Competitor,
    apiKey?: string
  ): Promise<number | null> {
    // If real API key is provided, attempt to fetch real data
    if (apiKey) {
      try {
        return await this.fetchPriceFromAPI(product, competitor, apiKey);
      } catch (error) {
        console.warn(`Real API fetch failed, falling back to simulation for ${competitor.name}:`, error);
        // Fall back to simulated data if API fails
      }
    }
    
    // Otherwise, generate simulated price data
    return this.generateSimulatedPrice(product, competitor);
  }
  
  /**
   * Fetch real price data from PriceAPI
   * Uses the jobs API with the correct parameters
   */
  private static async fetchPriceFromAPI(
    product: Product, 
    competitor: Competitor,
    apiKey: string
  ): Promise<number | null> {
    try {
      // Use the PriceAPI jobs endpoint with the correct parameters
      const apiEndpoint = 'https://api.priceapi.com/v2/jobs';
      
      // Step 1: Create a job to search for the product on the competitor's site
      const createResponse = await axios.post(apiEndpoint, {
        token: apiKey,
        source: competitor.website.includes('amazon') ? 'amazon' : 'walmart', // Default to major retailers
        country: 'us',
        topic: 'search_results', // Use the correct topic parameter
        query: product.name,     // Use the product name as the search query
        key: `competitor_price_${product.id}_${competitor.id}`,
        max_age: 86400 // Accept results up to 24 hours old for faster response
      });
      
      if (createResponse.status !== 200 || !createResponse.data?.id) {
        console.warn(`Failed to create price search job for ${product.name} at ${competitor.name}`);
        return null;
      }
      
      const jobId = createResponse.data.id;
      
      // Step 2: Poll for job completion
      let jobStatus = 'created';
      let attempts = 0;
      let jobResult = null;
      
      while (jobStatus !== 'finished' && jobStatus !== 'failed' && attempts < 10) {
        attempts++;
        
        // Wait a bit between polling attempts
        await new Promise(resolve => setTimeout(resolve, 1500));
        
        // Check job status
        const statusResponse = await axios.get(`https://api.priceapi.com/v2/jobs/${jobId}`, {
          params: { token: apiKey }
        });
        
        jobStatus = statusResponse.data?.status;
        
        if (jobStatus === 'finished') {
          jobResult = statusResponse.data?.result;
        }
      }
      
      // Step 3: Extract price from results
      if (jobStatus === 'finished' && jobResult) {
        const products = jobResult.products || [];
        
        // Find the most relevant product from search results
        // In a production app, you would implement better matching logic
        if (products.length > 0) {
          // Get the first product as the most relevant match
          const matchedProduct = products[0];
          
          // Extract price from offers if available
          if (matchedProduct.offers && matchedProduct.offers.length > 0 && matchedProduct.offers[0].price) {
            return parseFloat(matchedProduct.offers[0].price.value);
          }
        }
      }
      
      console.log(`No price found for ${product.name} at ${competitor.name} (Job status: ${jobStatus})`);
      return null;
    } catch (error) {
      console.error('PriceAPI fetch error:', error);
      return null;
    }
  }
  
  /**
   * Generate a simulated competitor price based on your own product price
   * Uses realistic price variations to simulate market conditions
   */
  private static generateSimulatedPrice(product: Product, competitor: Competitor): number {
    const basePrice = parseFloat(product.currentPrice);
    
    // Different competitors have different pricing strategies
    let variance: number;
    let priceModifier: number;
    
    // Customize price generation based on competitor
    switch (competitor.name.toLowerCase()) {
      case 'amazon':
        // Amazon typically has competitive prices
        variance = 0.10; // 10% variance
        priceModifier = -0.02; // Slightly lower on average
        break;
      case 'walmart':
        // Walmart often has lower prices
        variance = 0.15;
        priceModifier = -0.05; // 5% lower on average
        break;
      case 'best buy':
        // Best Buy might be higher for electronics
        variance = 0.12;
        priceModifier = 0.03; // 3% higher on average
        break;
      case 'target':
        // Target is usually midrange
        variance = 0.08;
        priceModifier = 0.01;
        break;
      default:
        // Default variance for other competitors
        variance = 0.10;
        priceModifier = 0;
    }
    
    // Generate random variance within the competitor's typical range
    const randomFactor = (Math.random() * 2 - 1) * variance;
    
    // Calculate the final price with the random variance and typical modifier
    const competitorPrice = basePrice * (1 + priceModifier + randomFactor);
    
    // Round to 2 decimal places
    return Math.round(competitorPrice * 100) / 100;
  }
  
  /**
   * Update a competitor's price for a specific product
   * Fetches the current price and updates it in the database
   */
  static async updateCompetitorPrice(productId: number, competitorId: number): Promise<void> {
    try {
      const product = await storage.getProduct(productId);
      const competitor = await storage.getCompetitor(competitorId);
      
      if (!product || !competitor) {
        throw new Error(`Product ${productId} or competitor ${competitorId} not found`);
      }
      
      const price = await this.fetchSingleCompetitorPrice(product, competitor);
      
      if (price) {
        // Get existing competitor price record
        const existingPrices = await storage.getCompetitorPrices(productId);
        const existingPrice = existingPrices.find(cp => cp.competitorId === competitorId);
        
        if (existingPrice) {
          // Update existing price
          await storage.updateCompetitorPrice(existingPrice.id, price.toString());
          
          // Add to price history
          await storage.createPriceHistory({
            productId,
            competitorId,
            price: price.toString(),
            timestamp: new Date()
          });
        } else {
          // Create new competitor price
          await storage.createCompetitorPrice({
            productId,
            competitorId,
            price: price.toString(),
            timestamp: new Date()
          });
        }
      }
    } catch (error) {
      console.error(`Error updating competitor price for product ${productId}, competitor ${competitorId}:`, error);
      throw error;
    }
  }
  
  /**
   * Update all competitor prices for all products
   * This would typically be run on a schedule
   */
  static async updateAllPrices(): Promise<void> {
    try {
      const products = await storage.getProducts();
      const competitors = await storage.getCompetitors();
      
      for (const product of products) {
        for (const competitor of competitors) {
          try {
            await this.updateCompetitorPrice(product.id, competitor.id);
          } catch (error) {
            console.error(`Failed to update price for product ${product.id}, competitor ${competitor.id}:`, error);
            // Continue with next item even if one fails
          }
        }
      }
    } catch (error) {
      console.error('Error updating all prices:', error);
      throw error;
    }
  }
}