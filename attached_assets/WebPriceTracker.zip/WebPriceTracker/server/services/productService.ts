import axios from 'axios';
import { storage } from '../storage';
import { InsertProduct } from '@shared/schema';

// This service handles product data operations
export class ProductService {
  // Fetch real product data from PriceAPI
  static async fetchExternalProducts(): Promise<InsertProduct[]> {
    try {
      const priceApiKey = process.env.PRICE_API_KEY;

      if (!priceApiKey) {
        throw new Error('PriceAPI key is not configured');
      }

      console.log('Fetching products from PriceAPI');

      // Search for electronics products using PriceAPI
      const response = await axios.get('https://api.priceapi.com/v2/jobs', {
        params: {
          token: priceApiKey,
          source: 'amazon',
          country: 'us',
          topic: 'search_results',
          key: 'term',
          term: 'electronics'
        }
      });

      console.log('PriceAPI search response status:', response.status);

      if (response.status !== 200) {
        throw new Error(`PriceAPI returned status ${response.status}`);
      }

      // Log partial response data for debugging
      console.log('PriceAPI response data:', JSON.stringify(response.data).substring(0, 300) + '...');

      const products: InsertProduct[] = [];

      // Process the search results
      if (response.data && response.data.jobs && response.data.jobs.length > 0) {
        const job = response.data.jobs[0];

        if (job.status === 'finished' && job.result && job.result.products) {
          // Map the PriceAPI product data to our product schema
          products.push(...job.result.products.map((p: any) => {
            // Extract category
            let category = 'Electronics';
            if (p.categories && p.categories.length > 0) {
              category = p.categories.map((c: any) => c.name).join(' / ');
            }

            // Extract price
            let price = 0;
            if (p.offers && p.offers.length > 0 && p.offers[0].price) {
              price = parseFloat(p.offers[0].price.value);
            }

            return {
              name: p.name,
              category: category,
              description: p.description || '',
              currentPrice: price,
              sku: p.id || `SKU-${Math.floor(Math.random() * 100000)}`,
              imageUrl: p.image || `https://source.unsplash.com/featured/?${encodeURIComponent(p.name)}`
            };
          }));
        }
      }

      console.log(`Fetched ${products.length} products from PriceAPI`);

      if (products.length === 0) {
        console.log('No products found, using default data');
      }

      return products;
    } catch (error) {
      console.error('Error fetching external products:', error);
      console.log('Using default product data');
      return [];
    }
  }

  // Import external products into our database
  static async importExternalProducts(): Promise<void> {
    const products = await this.fetchExternalProducts();

    for (const product of products) {
      await storage.createProduct(product);
    }
  }

  // Get all products with their competitor prices
  static async getProductsWithPrices() {
    return storage.getProductsWithCompetitorPrices();
  }
}