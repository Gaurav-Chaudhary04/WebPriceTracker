import { storage } from '../storage';

// This service handles price optimization logic
export class OptimizationService {
  // Optimize the price for a single product
  static async optimizeProductPrice(productId: number) {
    return storage.optimizeProductPrice(productId);
  }
  
  // Optimize prices for all products
  static async optimizeAllPrices() {
    return storage.optimizeAllPrices();
  }
  
  // Apply the suggested price to the current price
  static async applySuggestedPrice(productId: number) {
    const product = await storage.getProduct(productId);
    if (!product || !product.suggestedPrice) return null;
    
    const updatedProduct = await storage.updateProduct(productId, {
      currentPrice: product.suggestedPrice
    });
    
    // Add to price history
    if (updatedProduct) {
      await storage.createPriceHistory({
        productId,
        price: updatedProduct.currentPrice
      });
    }
    
    return updatedProduct;
  }
  
  // Apply all suggested prices
  static async applyAllSuggestedPrices() {
    const products = await storage.getProducts();
    const updatedProducts = [];
    
    for (const product of products) {
      if (product.suggestedPrice) {
        const updatedProduct = await this.applySuggestedPrice(product.id);
        if (updatedProduct) {
          updatedProducts.push(updatedProduct);
        }
      }
    }
    
    return updatedProducts;
  }
}
