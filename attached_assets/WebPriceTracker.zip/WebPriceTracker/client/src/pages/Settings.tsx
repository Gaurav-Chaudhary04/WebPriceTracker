import { useState } from 'react';
import { useToast } from '@/hooks/use-toast';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import * as z from 'zod';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { apiRequest } from '@/lib/queryClient';

// Settings form schema
const generalSettingsSchema = z.object({
  companyName: z.string().min(2, { message: 'Company name must be at least 2 characters.' }),
  email: z.string().email({ message: 'Please enter a valid email address.' }),
  currency: z.string(),
  timezone: z.string(),
  enableNotifications: z.boolean().default(true),
  priceUpdatesFrequency: z.string(),
});

const apiSettingsSchema = z.object({
  apiKey: z.string().optional(),
  enableRealTimeCompetitorTracking: z.boolean().default(false),
  competitorApiEndpoint: z.string().optional(),
});

export default function Settings() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("general");

  // General settings form
  const generalForm = useForm<z.infer<typeof generalSettingsSchema>>({
    resolver: zodResolver(generalSettingsSchema),
    defaultValues: {
      companyName: 'My Company',
      email: 'user@example.com',
      currency: 'USD',
      timezone: 'UTC',
      enableNotifications: true,
      priceUpdatesFrequency: 'daily',
    },
  });

  // API settings form
  const apiForm = useForm<z.infer<typeof apiSettingsSchema>>({
    resolver: zodResolver(apiSettingsSchema),
    defaultValues: {
      apiKey: '',
      enableRealTimeCompetitorTracking: false,
      competitorApiEndpoint: '',
    },
  });

  const onSaveGeneralSettings = async (data: z.infer<typeof generalSettingsSchema>) => {
    try {
      await apiRequest('POST', '/api/settings/general', data);
      toast({
        title: "Settings saved",
        description: "Your general settings have been updated successfully.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "There was a problem saving your settings.",
        variant: "destructive",
      });
    }
  };

  const onSaveApiSettings = async (data: z.infer<typeof apiSettingsSchema>) => {
    try {
      await apiRequest('POST', '/api/settings/api', data);
      toast({
        title: "API settings saved",
        description: "Your API settings have been updated successfully.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "There was a problem saving your API settings.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="p-4">
      {/* Page Header */}
      <div className="mb-6">
        <h1 className="text-2xl font-bold">Settings</h1>
        <p className="text-muted-foreground mt-1">Configure application settings and preferences</p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList>
          <TabsTrigger value="general">General</TabsTrigger>
          <TabsTrigger value="api">API Integration</TabsTrigger>
          <TabsTrigger value="appearance">Appearance</TabsTrigger>
          <TabsTrigger value="notifications">Notifications</TabsTrigger>
        </TabsList>

        {/* General Settings */}
        <TabsContent value="general">
          <Card>
            <CardHeader>
              <CardTitle>General Settings</CardTitle>
              <CardDescription>
                Configure basic application settings and preferences.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...generalForm}>
                <form id="general-settings-form" onSubmit={generalForm.handleSubmit(onSaveGeneralSettings)} className="space-y-4">
                  <FormField
                    control={generalForm.control}
                    name="companyName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Company Name</FormLabel>
                        <FormControl>
                          <Input placeholder="Your company name" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={generalForm.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email Address</FormLabel>
                        <FormControl>
                          <Input placeholder="email@example.com" {...field} />
                        </FormControl>
                        <FormDescription>
                          Email for notifications and alerts.
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={generalForm.control}
                      name="currency"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Currency</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select a currency" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="USD">USD ($)</SelectItem>
                              <SelectItem value="EUR">EUR (€)</SelectItem>
                              <SelectItem value="GBP">GBP (£)</SelectItem>
                              <SelectItem value="JPY">JPY (¥)</SelectItem>
                              <SelectItem value="CNY">CNY (¥)</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={generalForm.control}
                      name="timezone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Timezone</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select a timezone" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="UTC">UTC</SelectItem>
                              <SelectItem value="EST">Eastern Time (EST)</SelectItem>
                              <SelectItem value="CST">Central Time (CST)</SelectItem>
                              <SelectItem value="MST">Mountain Time (MST)</SelectItem>
                              <SelectItem value="PST">Pacific Time (PST)</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={generalForm.control}
                    name="priceUpdatesFrequency"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Price Updates Frequency</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select frequency" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="hourly">Hourly</SelectItem>
                            <SelectItem value="daily">Daily</SelectItem>
                            <SelectItem value="weekly">Weekly</SelectItem>
                            <SelectItem value="monthly">Monthly</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormDescription>
                          How often competitor prices should be checked.
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={generalForm.control}
                    name="enableNotifications"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                        <div className="space-y-0.5">
                          <FormLabel className="text-base">
                            Email Notifications
                          </FormLabel>
                          <FormDescription>
                            Receive email alerts for price changes and recommendations.
                          </FormDescription>
                        </div>
                        <FormControl>
                          <Switch
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                </form>
              </Form>
            </CardContent>
            <CardFooter>
              <Button type="submit" form="general-settings-form">
                Save General Settings
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        {/* API Integration Settings */}
        <TabsContent value="api">
          <Card>
            <CardHeader>
              <CardTitle>API Integration</CardTitle>
              <CardDescription>
                Configure external API integrations for real-time competitor price tracking.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...apiForm}>
                <form id="api-settings-form" onSubmit={apiForm.handleSubmit(onSaveApiSettings)} className="space-y-4">
                  <FormField
                    control={apiForm.control}
                    name="apiKey"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>API Key</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter your API key" {...field} />
                        </FormControl>
                        <FormDescription>
                          API key for accessing external price data services.
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={apiForm.control}
                    name="competitorApiEndpoint"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Competitor API Endpoint</FormLabel>
                        <FormControl>
                          <Input placeholder="https://api.example.com/v1/prices" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={apiForm.control}
                    name="enableRealTimeCompetitorTracking"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                        <div className="space-y-0.5">
                          <FormLabel className="text-base">
                            Real-time Competitor Price Tracking
                          </FormLabel>
                          <FormDescription>
                            Enable real-time tracking of competitor prices using API integrations.
                          </FormDescription>
                        </div>
                        <FormControl>
                          <Switch
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                </form>
              </Form>
            </CardContent>
            <CardFooter>
              <Button type="submit" form="api-settings-form">
                Save API Settings
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        {/* Appearance Settings */}
        <TabsContent value="appearance">
          <Card>
            <CardHeader>
              <CardTitle>Appearance</CardTitle>
              <CardDescription>
                Customize the application's appearance and theme.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <h3 className="text-lg font-medium">Theme</h3>
                  <p className="text-sm text-muted-foreground mb-3">
                    Choose the application theme
                  </p>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    <div className="border rounded-lg p-4 cursor-pointer hover:bg-accent hover:text-accent-foreground flex flex-col items-center bg-primary/5">
                      <div className="w-full h-24 bg-primary mb-2 rounded-md"></div>
                      <span className="text-sm font-medium">Default</span>
                    </div>
                    <div className="border rounded-lg p-4 cursor-pointer hover:bg-accent hover:text-accent-foreground flex flex-col items-center">
                      <div className="w-full h-24 bg-blue-500 mb-2 rounded-md"></div>
                      <span className="text-sm font-medium">Blue</span>
                    </div>
                    <div className="border rounded-lg p-4 cursor-pointer hover:bg-accent hover:text-accent-foreground flex flex-col items-center">
                      <div className="w-full h-24 bg-green-500 mb-2 rounded-md"></div>
                      <span className="text-sm font-medium">Green</span>
                    </div>
                    <div className="border rounded-lg p-4 cursor-pointer hover:bg-accent hover:text-accent-foreground flex flex-col items-center">
                      <div className="w-full h-24 bg-purple-500 mb-2 rounded-md"></div>
                      <span className="text-sm font-medium">Purple</span>
                    </div>
                    <div className="border rounded-lg p-4 cursor-pointer hover:bg-accent hover:text-accent-foreground flex flex-col items-center">
                      <div className="w-full h-24 bg-orange-500 mb-2 rounded-md"></div>
                      <span className="text-sm font-medium">Orange</span>
                    </div>
                    <div className="border rounded-lg p-4 cursor-pointer hover:bg-accent hover:text-accent-foreground flex flex-col items-center">
                      <div className="w-full h-24 bg-red-500 mb-2 rounded-md"></div>
                      <span className="text-sm font-medium">Red</span>
                    </div>
                  </div>
                </div>

                <Separator />

                <div>
                  <h3 className="text-lg font-medium">Color Mode</h3>
                  <p className="text-sm text-muted-foreground mb-3">
                    Choose between light and dark modes
                  </p>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="border rounded-lg p-4 cursor-pointer hover:bg-accent hover:text-accent-foreground flex flex-col items-center bg-primary/5">
                      <div className="w-full h-24 bg-white border mb-2 rounded-md"></div>
                      <span className="text-sm font-medium">Light</span>
                    </div>
                    <div className="border rounded-lg p-4 cursor-pointer hover:bg-accent hover:text-accent-foreground flex flex-col items-center">
                      <div className="w-full h-24 bg-gray-800 mb-2 rounded-md"></div>
                      <span className="text-sm font-medium">Dark</span>
                    </div>
                  </div>
                </div>

                <Separator />

                <div>
                  <h3 className="text-lg font-medium">Layout Density</h3>
                  <p className="text-sm text-muted-foreground mb-3">
                    Adjust the spacing in tables and lists
                  </p>
                  <div className="grid grid-cols-3 gap-4">
                    <div className="border rounded-lg p-4 cursor-pointer hover:bg-accent hover:text-accent-foreground text-center">
                      <span className="text-sm font-medium">Compact</span>
                    </div>
                    <div className="border rounded-lg p-4 cursor-pointer hover:bg-accent hover:text-accent-foreground text-center bg-primary/5">
                      <span className="text-sm font-medium">Default</span>
                    </div>
                    <div className="border rounded-lg p-4 cursor-pointer hover:bg-accent hover:text-accent-foreground text-center">
                      <span className="text-sm font-medium">Comfortable</span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button>Save Appearance Settings</Button>
            </CardFooter>
          </Card>
        </TabsContent>

        {/* Notification Settings */}
        <TabsContent value="notifications">
          <Card>
            <CardHeader>
              <CardTitle>Notification Settings</CardTitle>
              <CardDescription>
                Configure when and how you receive notifications.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <h3 className="text-lg font-medium">Email Notifications</h3>
                <div className="space-y-2">
                  {[
                    {
                      id: 'price-drop',
                      title: 'Price Drops',
                      description: 'Get notified when competitor prices drop below your prices.',
                      defaultChecked: true,
                    },
                    {
                      id: 'price-increase',
                      title: 'Price Increases',
                      description: 'Get notified when competitor prices increase above your prices.',
                      defaultChecked: true,
                    },
                    {
                      id: 'optimization-suggestions',
                      title: 'Optimization Suggestions',
                      description: 'Get notified about new price optimization suggestions.',
                      defaultChecked: true,
                    },
                    {
                      id: 'new-competitor',
                      title: 'New Competitor Detected',
                      description: 'Get notified when a new competitor is detected for your products.',
                      defaultChecked: false,
                    },
                    {
                      id: 'weekly-report',
                      title: 'Weekly Report',
                      description: 'Receive a weekly summary of price changes and recommendations.',
                      defaultChecked: true,
                    },
                    {
                      id: 'system-updates',
                      title: 'System Updates',
                      description: 'Receive notifications about system updates and maintenance.',
                      defaultChecked: false,
                    },
                  ].map((item) => (
                    <div key={item.id} className="flex items-center space-x-2">
                      <Switch id={item.id} defaultChecked={item.defaultChecked} />
                      <div className="grid gap-1.5">
                        <label
                          htmlFor={item.id}
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          {item.title}
                        </label>
                        <p className="text-sm text-muted-foreground">
                          {item.description}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button>Save Notification Settings</Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}