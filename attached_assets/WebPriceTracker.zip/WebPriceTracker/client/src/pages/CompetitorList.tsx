import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Plus, RefreshCw } from 'lucide-react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { apiRequest } from '@/lib/queryClient';
import AddCompetitorForm from '@/components/AddCompetitorForm';

export default function CompetitorList() {
  const { toast } = useToast();
  const [isAddCompetitorOpen, setIsAddCompetitorOpen] = useState(false);
  
  // Fetch competitors
  const { data: competitors = [], isLoading, refetch } = useQuery({
    queryKey: ['/api/competitors'],
  });

  const handleRefreshCompetitors = async () => {
    try {
      await apiRequest('POST', '/api/update-all-competitor-prices', {});
      await refetch();
      
      toast({
        title: "Success",
        description: "Competitor prices have been updated successfully."
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update competitor prices.",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="p-4">
      {/* Page Header */}
      <div className="mb-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-2xl font-bold">Competitors</h1>
            <p className="text-muted-foreground mt-1">Manage competitor information and track their pricing</p>
          </div>
          <div className="flex items-center space-x-2 mt-4 md:mt-0">
            <Button variant="outline" onClick={handleRefreshCompetitors} className="gap-2">
              <RefreshCw className="h-4 w-4" />
              Refresh Prices
            </Button>
            <Button className="gap-2" onClick={() => setIsAddCompetitorOpen(true)}>
              <Plus className="h-4 w-4" />
              Add Competitor
            </Button>
          </div>
        </div>
      </div>
      
      {/* Competitors List */}
      <Card>
        <CardHeader>
          <CardTitle>Tracked Competitors</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-2">
              {[...Array(3)].map((_, i) => (
                <Skeleton key={i} className="w-full h-12" />
              ))}
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Website</TableHead>
                  <TableHead>Products Matched</TableHead>
                  <TableHead>Average Price Difference</TableHead>
                  <TableHead>Last Updated</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {competitors.length > 0 ? (
                  competitors.map((competitor: any) => (
                    <TableRow key={competitor.id}>
                      <TableCell className="font-medium">{competitor.name}</TableCell>
                      <TableCell>{competitor.website}</TableCell>
                      <TableCell>{competitor.productsMatched || "N/A"}</TableCell>
                      <TableCell>
                        {competitor.avgPriceDifference 
                          ? `${competitor.avgPriceDifference > 0 ? "+" : ""}${competitor.avgPriceDifference.toFixed(2)}%` 
                          : "N/A"}
                      </TableCell>
                      <TableCell>
                        {competitor.lastUpdated
                          ? new Date(competitor.lastUpdated).toLocaleDateString()
                          : "Never"}
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center py-6 text-muted-foreground">
                      No competitors added yet. Add your first competitor to start tracking.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Add Competitor Dialog */}
      <AddCompetitorForm 
        isOpen={isAddCompetitorOpen} 
        onClose={() => setIsAddCompetitorOpen(false)} 
      />
    </div>
  );
}