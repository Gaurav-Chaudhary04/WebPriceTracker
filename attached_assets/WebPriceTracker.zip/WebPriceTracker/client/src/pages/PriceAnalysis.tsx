import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  BarChart,
  Bar,
  Cell
} from 'recharts';
import { Skeleton } from '@/components/ui/skeleton';
import { Button } from '@/components/ui/button';
import { RefreshCw, Zap } from 'lucide-react';
import { ProductWithCompetitorPrices, PriceTrend } from '@shared/schema';
import { apiRequest } from '@/lib/queryClient';

export default function PriceAnalysis() {
  const [selectedProductId, setSelectedProductId] = useState<number>(1);
  const [timeframe, setTimeframe] = useState<string>("30");
  
  // Fetch products data
  const { data: products = [], isLoading: isLoadingProducts } = useQuery<ProductWithCompetitorPrices[]>({
    queryKey: ['/api/products-with-prices'],
  });
  
  // Fetch price trends for the selected product
  const { data: trendData = [], isLoading: isLoadingTrends, refetch: refetchTrends } = useQuery<PriceTrend[]>({
    queryKey: ['/api/price-trends', selectedProductId, timeframe],
    enabled: selectedProductId > 0,
  });

  // Format data for charts
  const chartData = trendData.map(item => {
    const dataPoint: any = {
      date: new Date(item.date).toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric'
      }),
      yourPrice: item.yourPrice
    };
    
    // Add competitor prices
    item.competitorPrices.forEach(cp => {
      dataPoint[cp.competitorName] = cp.price;
    });
    
    return dataPoint;
  });

  // Calculate average competitor prices for each product
  const productPriceData = products.map(product => {
    // Skip if no competitor prices
    if (product.competitorPrices.length === 0) return null;
    
    // Calculate average competitor price
    const avgCompetitorPrice = product.competitorPrices.reduce((sum, cp) => 
      sum + cp.price, 0) / product.competitorPrices.length;
    
    // Calculate price difference
    const priceDifference = product.currentPrice - avgCompetitorPrice;
    const percentDifference = (priceDifference / avgCompetitorPrice) * 100;
    
    return {
      name: product.name.length > 15 ? product.name.substring(0, 15) + "..." : product.name,
      yourPrice: product.currentPrice,
      avgCompetitorPrice,
      priceDifference,
      percentDifference
    };
  }).filter(Boolean);

  const handleRefreshAnalysis = async () => {
    await apiRequest('POST', '/api/optimize-prices', {});
    refetchTrends();
  };

  return (
    <div className="p-4">
      {/* Page Header */}
      <div className="mb-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-2xl font-bold">Price Analysis</h1>
            <p className="text-muted-foreground mt-1">Analyze price trends and competitor pricing</p>
          </div>
          <div className="flex items-center space-x-2 mt-4 md:mt-0">
            <Button variant="outline" onClick={handleRefreshAnalysis} className="gap-2">
              <RefreshCw className="h-4 w-4" />
              Refresh Analysis
            </Button>
            <Button className="gap-2">
              <Zap className="h-4 w-4" />
              Generate Report
            </Button>
          </div>
        </div>
      </div>

      {/* Price Trend Analysis */}
      <Card className="mb-6">
        <CardHeader className="border-b flex flex-col sm:flex-row justify-between items-start sm:items-center">
          <CardTitle>Price Trend Analysis</CardTitle>
          <div className="flex items-center gap-2 mt-2 sm:mt-0">
            <Select value={selectedProductId.toString()} onValueChange={(value) => setSelectedProductId(Number(value))}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Select a product" />
              </SelectTrigger>
              <SelectContent>
                {products.map(product => (
                  <SelectItem key={product.id} value={product.id.toString()}>
                    {product.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <Select value={timeframe} onValueChange={setTimeframe}>
              <SelectTrigger className="w-[120px]">
                <SelectValue placeholder="Timeframe" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="7">Last 7 days</SelectItem>
                <SelectItem value="30">Last 30 days</SelectItem>
                <SelectItem value="90">Last 3 months</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent className="pt-6">
          <div style={{ height: 400 }}>
            {isLoadingTrends ? (
              <Skeleton className="w-full h-full" />
            ) : chartData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <LineChart
                  data={chartData}
                  margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis tickFormatter={(value) => `$${value}`} />
                  <Tooltip formatter={(value) => [`$${value}`, '']} />
                  <Legend />
                  <Line 
                    type="monotone" 
                    dataKey="yourPrice" 
                    name="Your Price"
                    stroke="hsl(var(--chart-1))" 
                    strokeWidth={2}
                    activeDot={{ r: 8 }} 
                  />
                  <Line 
                    type="monotone" 
                    dataKey="Amazon" 
                    stroke="hsl(var(--chart-2))" 
                    strokeDasharray="5 5"
                  />
                  <Line 
                    type="monotone" 
                    dataKey="Walmart" 
                    stroke="hsl(var(--chart-3))" 
                    strokeDasharray="5 5"
                  />
                  <Line 
                    type="monotone" 
                    dataKey="Best Buy" 
                    stroke="hsl(var(--chart-4))" 
                    strokeDasharray="5 5"
                  />
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-muted-foreground">
                No price data available for this product
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Product Price Comparison */}
      <Card>
        <CardHeader className="border-b">
          <CardTitle>Product Price Comparison</CardTitle>
        </CardHeader>
        <CardContent className="pt-6">
          <div style={{ height: 400 }}>
            {isLoadingProducts ? (
              <Skeleton className="w-full h-full" />
            ) : productPriceData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={productPriceData}
                  margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                  layout="vertical"
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis type="number" tickFormatter={(value) => `${value}%`} />
                  <YAxis type="category" dataKey="name" width={150} />
                  <Tooltip 
                    formatter={(value, name) => {
                      if (name === 'percentDifference') return [`${value.toFixed(2)}%`, 'Price Difference'];
                      return [value, name];
                    }}
                  />
                  <Legend />
                  <Bar 
                    dataKey="percentDifference" 
                    name="Price Difference (%)" 
                    fill="hsl(var(--chart-5))"
                  >
                    {productPriceData.map((entry, index) => (
                      <Cell 
                        key={`cell-${index}`} 
                        fill={entry.percentDifference > 0 ? "hsl(var(--destructive))" : "hsl(var(--success))"}
                      />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-muted-foreground">
                No comparison data available
              </div>
            )}
          </div>
          <div className="text-sm text-muted-foreground mt-4">
            <p>Chart shows your price compared to average competitor price (positive % means your price is higher)</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}