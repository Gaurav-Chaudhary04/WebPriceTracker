import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import StatCards from '@/components/StatCards';
import PriceChart from '@/components/PriceChart';
import ProductTable from '@/components/ProductTable';
import CompetitorInsights from '@/components/CompetitorInsights';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { Wand2 } from 'lucide-react';
import { ProductWithCompetitorPrices } from '@shared/schema';

export default function Dashboard() {
  const { toast } = useToast();
  const [selectedProductId, setSelectedProductId] = useState<number>(1);
  const [timeframe, setTimeframe] = useState<string>("7");

  // Fetch products with competitor prices
  const { data: products = [], isLoading: isLoadingProducts, refetch: refetchProducts } = useQuery<ProductWithCompetitorPrices[]>({
    queryKey: ['/api/products-with-prices'],
  });

  // Handle optimizing all prices
  const handleOptimizeAllPrices = async () => {
    try {
      await apiRequest('POST', '/api/apply-all-suggested-prices', {});
      
      // Refetch products to get the updated prices
      await refetchProducts();
      
      toast({
        title: "Success",
        description: "All prices have been successfully optimized!",
        variant: "success",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to optimize prices. Please try again.",
        variant: "destructive",
      });
    }
  };

  // Calculate dashboard stats
  const totalProducts = products.length;
  const priceChangeAlerts = products.filter(p => 
    p.competitorPrices.some(cp => 
      Math.abs(cp.price - p.currentPrice) / p.currentPrice > 0.05
    )
  ).length;
  
  const competitorsTracked = products.length > 0 
    ? products[0].competitorPrices.length 
    : 3;
  
  const potentialSavings = products.reduce((sum, product) => {
    if (product.suggestedPrice && product.currentPrice > product.suggestedPrice) {
      return sum + (product.currentPrice - product.suggestedPrice);
    }
    return sum;
  }, 0).toFixed(2);

  return (
    <div className="p-4">
      {/* Page Header */}
      <div className="mb-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-2xl font-bold">Dashboard</h1>
            <p className="text-muted-foreground mt-1">Overview of products and competitive pricing</p>
          </div>
          <div className="mt-4 md:mt-0">
            <Button onClick={handleOptimizeAllPrices} className="gap-2">
              <Wand2 className="h-4 w-4" />
              Optimize All Prices
            </Button>
          </div>
        </div>
      </div>

      {/* Stat Cards */}
      <StatCards 
        totalProducts={totalProducts} 
        priceChangeAlerts={priceChangeAlerts} 
        competitorsTracked={competitorsTracked} 
        potentialSavings={potentialSavings} 
      />

      {/* Product Analysis Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        {/* Price Chart */}
        <div className="lg:col-span-2 bg-card rounded-lg shadow p-4">
          <PriceChart 
            productId={selectedProductId} 
            products={products} 
            timeframe={timeframe}
            onProductChange={(id) => setSelectedProductId(Number(id))}
            onTimeframeChange={(days) => setTimeframe(days)}
          />
        </div>

        {/* Competitor Insights */}
        <CompetitorInsights products={products} />
      </div>

      {/* Products Table */}
      <ProductTable 
        products={products} 
        isLoading={isLoadingProducts} 
        onRefetch={refetchProducts} 
      />
    </div>
  );
}
