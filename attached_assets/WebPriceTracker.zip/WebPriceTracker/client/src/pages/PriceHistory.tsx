import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { DateRange } from 'react-day-picker';
import { addDays, format } from 'date-fns';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Button } from '@/components/ui/button';
import { CalendarIcon, Download } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import { 
  ResponsiveContainer, 
  ComposedChart, 
  Line, 
  Area, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend 
} from 'recharts';
import { cn } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { PriceHistory } from '@shared/schema';

export default function PriceHistoryPage() {
  const [selectedProductId, setSelectedProductId] = useState<number>(1);
  const [date, setDate] = useState<DateRange | undefined>({
    from: addDays(new Date(), -30),
    to: new Date(),
  });

  // Get all products
  const { data: products = [], isLoading: isLoadingProducts } = useQuery({
    queryKey: ['/api/products'],
  });

  // Get price history for selected product
  const { data: priceHistory = [], isLoading: isLoadingHistory } = useQuery<PriceHistory[]>({
    queryKey: ['/api/price-history', selectedProductId, date?.from, date?.to],
    enabled: !!selectedProductId && !!date?.from,
  });

  const chartData = priceHistory.map((item: any) => {
    const dataPoint: any = {
      date: new Date(item.timestamp).toLocaleDateString(),
      yourPrice: parseFloat(item.price),
    };
    
    // If there's competitor data available
    if (item.competitorPrices) {
      item.competitorPrices.forEach((cp: any) => {
        dataPoint[cp.competitorName] = parseFloat(cp.price);
      });
    }
    
    return dataPoint;
  });

  return (
    <div className="p-4">
      {/* Page Header */}
      <div className="mb-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-2xl font-bold">Price History</h1>
            <p className="text-muted-foreground mt-1">View historical price data and trends over time</p>
          </div>
          <div className="flex items-center space-x-2 mt-4 md:mt-0">
            <Button variant="outline" className="gap-2">
              <Download className="h-4 w-4" />
              Export Data
            </Button>
          </div>
        </div>
      </div>

      {/* Filters */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Filter Price History</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-3">
            <div>
              <label className="text-sm font-medium mb-2 block">Product</label>
              <Select 
                value={selectedProductId.toString()} 
                onValueChange={(value) => setSelectedProductId(Number(value))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select a product" />
                </SelectTrigger>
                <SelectContent>
                  {products.map((product: any) => (
                    <SelectItem key={product.id} value={product.id.toString()}>
                      {product.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">Date Range</label>
              <div className="grid gap-2">
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      id="date"
                      variant={"outline"}
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !date && "text-muted-foreground"
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {date?.from ? (
                        date.to ? (
                          <>
                            {format(date.from, "LLL dd, y")} -{" "}
                            {format(date.to, "LLL dd, y")}
                          </>
                        ) : (
                          format(date.from, "LLL dd, y")
                        )
                      ) : (
                        <span>Pick a date</span>
                      )}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      initialFocus
                      mode="range"
                      defaultMonth={date?.from}
                      selected={date}
                      onSelect={setDate}
                      numberOfMonths={2}
                    />
                  </PopoverContent>
                </Popover>
              </div>
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">Quick Select</label>
              <Select 
                onValueChange={(value) => {
                  const today = new Date();
                  switch (value) {
                    case '7days':
                      setDate({ from: addDays(today, -7), to: today });
                      break;
                    case '30days':
                      setDate({ from: addDays(today, -30), to: today });
                      break;
                    case '90days':
                      setDate({ from: addDays(today, -90), to: today });
                      break;
                    case '1year':
                      setDate({ from: addDays(today, -365), to: today });
                      break;
                  }
                }}
                defaultValue="30days"
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select timeframe" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="7days">Last 7 days</SelectItem>
                  <SelectItem value="30days">Last 30 days</SelectItem>
                  <SelectItem value="90days">Last 90 days</SelectItem>
                  <SelectItem value="1year">Last year</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Price History Chart */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Price Trends</CardTitle>
        </CardHeader>
        <CardContent>
          <div style={{ height: 400 }}>
            {isLoadingHistory || isLoadingProducts ? (
              <Skeleton className="w-full h-full" />
            ) : chartData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <ComposedChart
                  data={chartData}
                  margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis tickFormatter={(value) => `$${value}`} />
                  <Tooltip formatter={(value) => [`$${value}`, '']} />
                  <Legend />
                  <Area 
                    type="monotone" 
                    dataKey="yourPrice" 
                    name="Your Price" 
                    fill="hsl(var(--primary)/0.2)" 
                    stroke="hsl(var(--primary))" 
                    fillOpacity={0.3} 
                  />
                  <Line 
                    type="monotone" 
                    dataKey="Amazon" 
                    stroke="hsl(var(--chart-1))" 
                  />
                  <Line 
                    type="monotone" 
                    dataKey="Walmart" 
                    stroke="hsl(var(--chart-2))" 
                  />
                  <Line 
                    type="monotone" 
                    dataKey="Best Buy" 
                    stroke="hsl(var(--chart-3))" 
                  />
                </ComposedChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-muted-foreground">
                No price history data available. Select a product to view its price history.
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Price History Data Table */}
      <Card>
        <CardHeader>
          <CardTitle>Price History Data</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoadingHistory ? (
            <div className="space-y-2">
              {[...Array(5)].map((_, i) => (
                <Skeleton key={i} className="w-full h-12" />
              ))}
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Your Price</TableHead>
                  <TableHead>Avg. Competitor Price</TableHead>
                  <TableHead>Price Difference</TableHead>
                  <TableHead>Change From Previous</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {chartData.length > 0 ? (
                  chartData.map((entry: any, index: number) => {
                    // Calculate average competitor price
                    const competitorPrices = Object.entries(entry)
                      .filter(([key]) => !['date', 'yourPrice'].includes(key))
                      .map(([_, value]) => value as number);
                    
                    const avgCompetitorPrice = competitorPrices.length > 0
                      ? competitorPrices.reduce((sum, price) => sum + (price as number), 0) / competitorPrices.length
                      : 0;
                    
                    // Calculate difference
                    const difference = avgCompetitorPrice > 0
                      ? entry.yourPrice - avgCompetitorPrice
                      : 0;
                    
                    const percentDifference = avgCompetitorPrice > 0
                      ? (difference / avgCompetitorPrice) * 100
                      : 0;
                    
                    // Calculate change from previous day
                    const previousEntry = index < chartData.length - 1 ? chartData[index + 1] : null;
                    const priceChange = previousEntry
                      ? entry.yourPrice - previousEntry.yourPrice
                      : 0;
                    
                    const percentChange = previousEntry && previousEntry.yourPrice
                      ? (priceChange / previousEntry.yourPrice) * 100
                      : 0;
                    
                    return (
                      <TableRow key={entry.date}>
                        <TableCell>{entry.date}</TableCell>
                        <TableCell>${entry.yourPrice.toFixed(2)}</TableCell>
                        <TableCell>
                          {avgCompetitorPrice > 0 
                            ? `$${avgCompetitorPrice.toFixed(2)}` 
                            : "N/A"}
                        </TableCell>
                        <TableCell>
                          {avgCompetitorPrice > 0 ? (
                            <div className="flex items-center gap-2">
                              <Badge 
                                variant={difference < 0 ? "success" : "destructive"}
                                className="font-medium"
                              >
                                {difference > 0 ? "+" : ""}{difference.toFixed(2)} ({percentDifference.toFixed(1)}%)
                              </Badge>
                            </div>
                          ) : "N/A"}
                        </TableCell>
                        <TableCell>
                          {previousEntry ? (
                            <div className="flex items-center gap-2">
                              <Badge 
                                variant={priceChange <= 0 ? "outline" : "destructive"}
                                className="font-medium"
                              >
                                {priceChange > 0 ? "+" : ""}{priceChange.toFixed(2)} ({percentChange.toFixed(1)}%)
                              </Badge>
                            </div>
                          ) : "N/A"}
                        </TableCell>
                      </TableRow>
                    );
                  })
                ) : (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center h-24 text-muted-foreground">
                      No price history data available
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}