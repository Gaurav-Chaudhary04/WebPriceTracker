import { useQuery } from '@tanstack/react-query';
import { useState } from 'react';
import { useToast } from '@/hooks/use-toast';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { ProductWithCompetitorPrices, productCategories, InsertProduct } from '@shared/schema';
import ProductTable from '@/components/ProductTable';
import AddProductForm from '@/components/AddProductForm';
import { Button } from '@/components/ui/button';
import { Plus, Database, RefreshCw } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Loader2 } from 'lucide-react';

export default function ProductList() {
  const { toast } = useToast();
  const [categoryFilter, setCategoryFilter] = useState<string>("All Categories");
  const [isAddProductOpen, setIsAddProductOpen] = useState(false);
  const [isImportingProducts, setIsImportingProducts] = useState(false);
  const [importResults, setImportResults] = useState<{
    success: boolean;
    message: string;
    products?: any[];
  } | null>(null);

  // Fetch products with competitor prices
  const { data: products = [], isLoading, refetch } = useQuery<ProductWithCompetitorPrices[]>({
    queryKey: ['/api/products-with-prices'],
  });

  // Function to fetch real products
  const fetchRealProducts = async () => {
    setIsImportingProducts(true);
    setImportResults(null);
    
    try {
      // Define the expected response type
      interface ApiProductResponse {
        status: string;
        message: string;
        products: Array<{
          name: string;
          description: string;
          category: string;
          currentPrice: number;
          sku: string;
          imageUrl: string | null;
        }>;
      }
      
      // Make the API request
      const response = await apiRequest<ApiProductResponse>('/api/fetch-real-products');
      
      if (response && response.products) {
        setImportResults({
          success: true,
          message: response.message || 'Successfully fetched real products',
          products: response.products
        });
        
        toast({
          title: 'Success!',
          description: `Found ${response.products.length} products from PriceAPI.`,
        });
      } else {
        throw new Error('Invalid response format from server');
      }
    } catch (error) {
      console.error('Error fetching real products:', error);
      const errorMessage = error instanceof Error 
        ? error.message 
        : 'Failed to fetch real products';
        
      setImportResults({
        success: false,
        message: errorMessage
      });
      
      toast({
        variant: 'destructive',
        title: 'Error',
        description: errorMessage.includes('API Error:') 
          ? errorMessage 
          : 'Failed to fetch real products. Check console for details.',
      });
    } finally {
      setIsImportingProducts(false);
    }
  };
  
  // Function to import the fetched products
  const importProducts = async () => {
    if (!importResults?.products || importResults.products.length === 0) {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'No products available to import.',
      });
      return;
    }
    
    setIsImportingProducts(true);
    
    try {
      // Import each product one by one
      const importedProducts = [];
      
      for (const product of importResults.products) {
        try {
          // Prepare product data according to the schema expected by the backend
          const productData = {
            name: product.name,
            category: product.category,
            description: product.description || '',
            currentPrice: product.currentPrice.toString(),
            sku: product.sku,
            imageUrl: product.imageUrl || null
          };
          
          const response = await apiRequest('/api/products', {
            method: 'POST',
            data: productData
          });
          
          importedProducts.push(response);
        } catch (error) {
          console.error('Error importing product:', product.name, error);
        }
      }
      
      // Invalidate products query to refresh the list
      queryClient.invalidateQueries({ queryKey: ['/api/products-with-prices'] });
      
      toast({
        title: 'Success!',
        description: `Imported ${importedProducts.length} products.`,
      });
      
      // Clear import results
      setImportResults(null);
      
    } catch (error) {
      console.error('Error importing products:', error);
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Failed to import some products. Check console for details.',
      });
    } finally {
      setIsImportingProducts(false);
    }
  };

  // Apply category filter
  const filteredProducts = categoryFilter === "All Categories" 
    ? products
    : products.filter(product => product.category === categoryFilter);

  return (
    <div className="p-4">
      {/* Page Header */}
      <div className="mb-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-2xl font-bold">Products</h1>
            <p className="text-muted-foreground mt-1">Manage your product catalog and pricing</p>
          </div>
          <div className="mt-4 md:mt-0">
            <Button className="gap-2" onClick={() => setIsAddProductOpen(true)}>
              <Plus className="h-4 w-4" />
              Add Product
            </Button>
          </div>
        </div>
      </div>

      {/* Filters and Import */}
      <Card className="mb-6">
        <CardHeader className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
          <CardTitle>Filters & Data Management</CardTitle>
          <div className="mt-2 sm:mt-0 flex space-x-2">
            <Button 
              variant="outline" 
              className="gap-2" 
              onClick={fetchRealProducts} 
              disabled={isImportingProducts}
            >
              {isImportingProducts ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Database className="h-4 w-4" />
              )}
              Fetch Real Products
            </Button>
            
            {importResults?.products && importResults.products.length > 0 && (
              <Button
                variant="default"
                className="gap-2"
                onClick={importProducts}
                disabled={isImportingProducts}
              >
                {isImportingProducts ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <RefreshCw className="h-4 w-4" />
                )}
                Import {importResults.products.length} Products
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-4 mb-4">
            <div className="w-full md:w-auto">
              <label className="block text-sm font-medium mb-1 text-muted-foreground">Category</label>
              <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                <SelectTrigger className="w-full md:w-[200px]">
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="All Categories">All Categories</SelectItem>
                  {productCategories.map(category => (
                    <SelectItem key={category} value={category}>{category}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          
          {/* Show import results */}
          {importResults && (
            <Alert variant={importResults.success ? 'default' : 'destructive'} className="mt-4">
              <AlertTitle>
                {importResults.success 
                  ? `Found ${importResults.products?.length || 0} products` 
                  : 'Error fetching products'}
              </AlertTitle>
              <AlertDescription>
                {importResults.message}
                
                {importResults.products && importResults.products.length > 0 && (
                  <div className="mt-2">
                    <p className="font-medium">Sample Products:</p>
                    <ul className="list-disc pl-5 mt-1">
                      {importResults.products.slice(0, 3).map((product, idx) => (
                        <li key={idx}>{product.name} - ${parseFloat(product.currentPrice).toFixed(2)}</li>
                      ))}
                      {importResults.products.length > 3 && (
                        <li>...and {importResults.products.length - 3} more</li>
                      )}
                    </ul>
                  </div>
                )}
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      {/* Products Table */}
      <ProductTable 
        products={filteredProducts} 
        isLoading={isLoading} 
        onRefetch={refetch}
      />
      
      {/* Add Product Dialog */}
      <AddProductForm 
        isOpen={isAddProductOpen} 
        onClose={() => setIsAddProductOpen(false)} 
      />
    </div>
  );
}
