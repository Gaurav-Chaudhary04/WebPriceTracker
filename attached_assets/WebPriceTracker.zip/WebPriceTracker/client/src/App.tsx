import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/Dashboard";
import ProductList from "@/pages/ProductList";
import PriceAnalysis from "@/pages/PriceAnalysis";
import PriceHistory from "@/pages/PriceHistory";
import CompetitorList from "@/pages/CompetitorList";
import Settings from "@/pages/Settings";
import Layout from "@/components/Layout";

function Router() {
  return (
    <Layout>
      <Switch>
        <Route path="/" component={Dashboard} />
        <Route path="/products" component={ProductList} />
        <Route path="/analysis" component={PriceAnalysis} />
        <Route path="/history" component={PriceHistory} />
        <Route path="/competitors" component={CompetitorList} />
        <Route path="/settings" component={Settings} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Router />
      <Toaster />
    </QueryClientProvider>
  );
}

export default App;
