import { useLocation, Link } from 'wouter';
import { cn } from '@/lib/utils';
import { 
  LayoutDashboard, 
  Package2, 
  TrendingUp, 
  History, 
  Store, 
  BarChart2, 
  Settings, 
  X 
} from 'lucide-react';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

interface NavItemProps {
  href: string;
  icon: React.ReactNode;
  label: string;
  active: boolean;
  onClick?: () => void;
}

function NavItem({ href, icon, label, active, onClick }: NavItemProps) {
  return (
    <Link
      href={href}
      className={cn(
        "flex items-center px-4 py-3 text-sm transition-colors",
        active 
          ? "text-primary bg-primary/5" 
          : "text-foreground hover:bg-muted"
      )}
      onClick={onClick}
    >
      <span className="mr-3">{icon}</span>
      <span>{label}</span>
    </Link>
  );
}

export default function Sidebar({ isOpen, onClose }: SidebarProps) {
  const [location] = useLocation();
  
  return (
    <>
      {/* Mobile backdrop */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-20 md:hidden" 
          onClick={onClose}
        />
      )}
      
      <aside 
        className={cn(
          "w-64 bg-card shadow-lg fixed h-full z-30 transform transition-transform duration-300 ease-in-out",
          isOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0"
        )}
      >
        <nav className="py-4 h-full flex flex-col">
          <div className="px-4 mb-6 md:hidden">
            <div className="flex items-center justify-between">
              <h1 className="text-xl font-bold text-primary">PriceOptim</h1>
              <button onClick={onClose} className="p-2">
                <X className="h-5 w-5" />
              </button>
            </div>
          </div>
          
          <div className="space-y-1 flex-1">
            <NavItem 
              href="/" 
              icon={<LayoutDashboard className="h-5 w-5" />} 
              label="Dashboard" 
              active={location === "/"} 
              onClick={onClose}
            />
            <NavItem 
              href="/products" 
              icon={<Package2 className="h-5 w-5" />} 
              label="Products" 
              active={location === "/products"} 
              onClick={onClose}
            />
            <NavItem 
              href="/analysis" 
              icon={<TrendingUp className="h-5 w-5" />} 
              label="Price Analysis" 
              active={location === "/analysis"} 
              onClick={onClose}
            />
            <NavItem 
              href="/history" 
              icon={<History className="h-5 w-5" />} 
              label="Price History" 
              active={location === "/history"} 
              onClick={onClose}
            />
            <NavItem 
              href="/competitors" 
              icon={<Store className="h-5 w-5" />} 
              label="Competitors" 
              active={location === "/competitors"} 
              onClick={onClose}
            />
            <NavItem 
              href="/reports" 
              icon={<BarChart2 className="h-5 w-5" />} 
              label="Reports" 
              active={location === "/reports"} 
              onClick={onClose}
            />
            <NavItem 
              href="/settings" 
              icon={<Settings className="h-5 w-5" />} 
              label="Settings" 
              active={location === "/settings"} 
              onClick={onClose}
            />
          </div>
          
          <div className="mt-auto px-4 py-2 text-center text-xs text-muted-foreground">
            <p>PriceOptim v1.0.0</p>
          </div>
        </nav>
      </aside>
    </>
  );
}
