import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { PriceTrend, ProductWithCompetitorPrices } from '@shared/schema';

interface PriceChartProps {
  productId: number;
  products: ProductWithCompetitorPrices[];
  timeframe: string;
  onProductChange: (id: string) => void;
  onTimeframeChange: (days: string) => void;
}

export default function PriceChart({ 
  productId, 
  products, 
  timeframe, 
  onProductChange, 
  onTimeframeChange 
}: PriceChartProps) {
  // Fetch price trend data for the selected product
  const { data: trendData, isLoading } = useQuery<PriceTrend[]>({
    queryKey: ['/api/price-trends', productId, timeframe],
    enabled: productId > 0,
  });

  // Prepare data for chart
  const [chartData, setChartData] = useState<any[]>([]);

  useEffect(() => {
    if (trendData) {
      const formattedData = trendData.map(item => {
        const dataPoint: any = {
          date: new Date(item.date).toLocaleDateString('en-US', {
            month: 'short',
            day: 'numeric'
          }),
          yourPrice: item.yourPrice
        };
        
        // Add competitor prices
        item.competitorPrices.forEach(cp => {
          dataPoint[cp.competitorName] = cp.price;
        });
        
        return dataPoint;
      });
      
      setChartData(formattedData);
    }
  }, [trendData]);

  return (
    <Card>
      <CardHeader className="flex flex-col sm:flex-row justify-between items-start sm:items-center">
        <CardTitle>Price Trends - Selected Product</CardTitle>
        <div className="flex items-center gap-2 mt-2 sm:mt-0">
          <Select value={productId.toString()} onValueChange={onProductChange}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select a product" />
            </SelectTrigger>
            <SelectContent>
              {products.map(product => (
                <SelectItem key={product.id} value={product.id.toString()}>
                  {product.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          
          <Select value={timeframe} onValueChange={onTimeframeChange}>
            <SelectTrigger className="w-[120px]">
              <SelectValue placeholder="Timeframe" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7">Last 7 days</SelectItem>
              <SelectItem value="30">Last 30 days</SelectItem>
              <SelectItem value="90">Last 3 months</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      <CardContent>
        <div style={{ height: 300 }}>
          {isLoading ? (
            <Skeleton className="w-full h-full" />
          ) : chartData.length > 0 ? (
            <ResponsiveContainer width="100%" height="100%">
              <LineChart
                data={chartData}
                margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis 
                  tickFormatter={(value) => `$${value}`}
                  domain={['auto', 'auto']}
                />
                <Tooltip formatter={(value) => [`$${value}`, '']} />
                <Legend />
                <Line 
                  type="monotone" 
                  dataKey="yourPrice" 
                  name="Your Price"
                  stroke="hsl(var(--chart-1))" 
                  strokeWidth={2}
                  activeDot={{ r: 8 }} 
                  isAnimationActive={true}
                />
                <Line 
                  type="monotone" 
                  dataKey="Amazon" 
                  stroke="hsl(var(--chart-2))" 
                  strokeDasharray="5 5"
                  isAnimationActive={true}
                />
                <Line 
                  type="monotone" 
                  dataKey="Walmart" 
                  stroke="hsl(var(--chart-3))" 
                  strokeDasharray="5 5"
                  isAnimationActive={true}
                />
                <Line 
                  type="monotone" 
                  dataKey="Best Buy" 
                  stroke="hsl(var(--chart-4))" 
                  strokeDasharray="5 5"
                  isAnimationActive={true}
                />
              </LineChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-full flex items-center justify-center text-muted-foreground">
              No price data available for this product
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
