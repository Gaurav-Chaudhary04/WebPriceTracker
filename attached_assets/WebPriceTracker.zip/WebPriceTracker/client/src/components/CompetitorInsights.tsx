import { useMemo } from 'react';
import { Link } from 'wouter';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ProductWithCompetitorPrices } from '@shared/schema';
import { Skeleton } from '@/components/ui/skeleton';
import { ArrowRight } from 'lucide-react';

interface CompetitorInsightsProps {
  products: ProductWithCompetitorPrices[];
}

interface CompetitorSummary {
  name: string;
  matches: number;
  avgPriceDifference: number;
  priceMatches: number;
}

export default function CompetitorInsights({ products }: CompetitorInsightsProps) {
  // Calculate competitor insights
  const competitorInsights = useMemo(() => {
    if (!products.length) return [];
    
    // Get unique competitor names
    const competitorNames = new Set<string>();
    products.forEach(product => {
      product.competitorPrices.forEach(cp => {
        competitorNames.add(cp.competitorName);
      });
    });
    
    // Calculate insights for each competitor
    return Array.from(competitorNames).map(name => {
      let matches = 0;
      let totalPriceDifference = 0;
      let priceMatches = 0;
      
      products.forEach(product => {
        const competitorPrice = product.competitorPrices.find(cp => cp.competitorName === name);
        if (competitorPrice) {
          matches++;
          totalPriceDifference += product.currentPrice - competitorPrice.price;
          
          // Count as price match if within 1%
          if (Math.abs(product.currentPrice - competitorPrice.price) / product.currentPrice < 0.01) {
            priceMatches++;
          }
        }
      });
      
      const avgPriceDifference = matches > 0 ? totalPriceDifference / matches : 0;
      
      return {
        name,
        matches,
        avgPriceDifference,
        priceMatches
      };
    });
  }, [products]);

  if (!products.length) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Competitor Insights</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <Skeleton className="h-20 w-full" />
            <Skeleton className="h-20 w-full" />
            <Skeleton className="h-20 w-full" />
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Competitor Insights</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {competitorInsights.map((competitor: CompetitorSummary) => (
            <div key={competitor.name} className="p-3 border rounded-md hover:bg-muted transition-colors">
              <div className="flex justify-between items-center">
                <h3 className="font-semibold">{competitor.name}</h3>
                <span className="text-blue-500 font-medium text-sm">{competitor.matches} matches</span>
              </div>
              <div className="mt-2">
                <div className="flex justify-between items-center text-sm">
                  <span className="text-muted-foreground">Avg. price difference</span>
                  <span className={competitor.avgPriceDifference > 0 ? "text-destructive font-medium" : "text-emerald-500 font-medium"}>
                    {competitor.avgPriceDifference > 0 ? "+" : ""}${Math.abs(competitor.avgPriceDifference).toFixed(2)}
                  </span>
                </div>
                <div className="flex justify-between items-center text-sm mt-1">
                  <span className="text-muted-foreground">Price matches</span>
                  <span>{competitor.priceMatches}/{products.length} products</span>
                </div>
              </div>
            </div>
          ))}
          
          <Link href="/analysis" className="block text-center text-primary hover:underline text-sm mt-2 flex items-center justify-center">
            View Full Competitor Analysis <ArrowRight className="h-3 w-3 ml-1" />
          </Link>
        </div>
      </CardContent>
    </Card>
  );
}
