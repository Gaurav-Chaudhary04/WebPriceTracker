import { Card, CardContent } from '@/components/ui/card';
import { Package2, BellRing, Store, PiggyBank } from 'lucide-react';

interface StatCardsProps {
  totalProducts: number;
  priceChangeAlerts: number;
  competitorsTracked: number;
  potentialSavings: string;
}

export default function StatCards({ 
  totalProducts, 
  priceChangeAlerts, 
  competitorsTracked, 
  potentialSavings 
}: StatCardsProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
      {/* Total Products */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-muted-foreground text-sm">Total Products</p>
              <h3 className="text-2xl font-semibold mt-1">{totalProducts}</h3>
            </div>
            <div className="bg-primary/10 p-3 rounded-full">
              <Package2 className="h-5 w-5 text-primary" />
            </div>
          </div>
        </CardContent>
      </Card>
      
      {/* Price Change Alerts */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-muted-foreground text-sm">Price Change Alerts</p>
              <h3 className="text-2xl font-semibold mt-1">{priceChangeAlerts}</h3>
            </div>
            <div className="bg-amber-50 p-3 rounded-full">
              <BellRing className="h-5 w-5 text-amber-500" />
            </div>
          </div>
        </CardContent>
      </Card>
      
      {/* Competitors Tracked */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-muted-foreground text-sm">Competitors Tracked</p>
              <h3 className="text-2xl font-semibold mt-1">{competitorsTracked}</h3>
            </div>
            <div className="bg-blue-50 p-3 rounded-full">
              <Store className="h-5 w-5 text-blue-500" />
            </div>
          </div>
        </CardContent>
      </Card>
      
      {/* Potential Savings */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-muted-foreground text-sm">Potential Savings</p>
              <h3 className="text-2xl font-semibold mt-1">${potentialSavings}</h3>
            </div>
            <div className="bg-emerald-50 p-3 rounded-full">
              <PiggyBank className="h-5 w-5 text-emerald-500" />
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
