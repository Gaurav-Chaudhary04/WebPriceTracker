import { Link } from 'wouter';
import { Menu, Bell, Search, User } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';

interface HeaderProps {
  onMenuClick: () => void;
}

export default function Header({ onMenuClick }: HeaderProps) {
  return (
    <header className="bg-primary text-primary-foreground shadow-md sticky top-0 z-10">
      <div className="container mx-auto px-4 py-3 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <button 
            onClick={onMenuClick} 
            className="md:hidden p-2 hover:bg-primary-foreground/10 rounded-md"
          >
            <Menu className="h-5 w-5" />
          </button>
          <Link href="/" className="text-xl font-bold">
            PriceOptim
          </Link>
        </div>
        <div className="flex items-center space-x-4">
          <div className="relative w-64 hidden md:block">
            <Input 
              type="text" 
              placeholder="Search products..." 
              className="w-full bg-primary-foreground/10 border-primary-foreground/20 text-primary-foreground placeholder:text-primary-foreground/50"
            />
            <Search className="absolute right-2 top-2.5 h-4 w-4 opacity-50" />
          </div>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="relative">
                <Bell className="h-5 w-5" />
                <span className="absolute top-1 right-1 w-4 h-4 bg-secondary rounded-full text-xs flex items-center justify-center">3</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>Notifications</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem>Price alert: Competitor reduced price on AirPods Pro</DropdownMenuItem>
              <DropdownMenuItem>Optimization suggestion available for Samsung Galaxy Watch</DropdownMenuItem>
              <DropdownMenuItem>New competitor price data available</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          
          <div className="hidden md:flex items-center space-x-2">
            <Avatar className="h-8 w-8 bg-primary-dark">
              <AvatarFallback>A</AvatarFallback>
            </Avatar>
            <span>Admin</span>
          </div>
        </div>
      </div>
    </header>
  );
}
