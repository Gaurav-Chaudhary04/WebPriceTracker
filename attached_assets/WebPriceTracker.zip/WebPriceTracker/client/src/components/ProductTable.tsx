import { useState } from 'react';
import { Eye, Wand2 } from 'lucide-react';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { ProductWithCompetitorPrices } from '@shared/schema';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';

interface ProductTableProps {
  products: ProductWithCompetitorPrices[];
  isLoading: boolean;
  onRefetch: () => void;
}

export default function ProductTable({ products, isLoading, onRefetch }: ProductTableProps) {
  const { toast } = useToast();
  const [categoryFilter, setCategoryFilter] = useState("All Categories");
  const [priceStatusFilter, setPriceStatusFilter] = useState("All Price Statuses");
  const [currentPage, setCurrentPage] = useState(1);
  const productsPerPage = 5;

  // Apply selected filters
  const filteredProducts = products.filter(product => {
    // Category filter
    if (categoryFilter !== "All Categories" && !product.category.includes(categoryFilter)) {
      return false;
    }

    // Price status filter
    if (priceStatusFilter !== "All Price Statuses") {
      const avgCompetitorPrice = product.competitorPrices.reduce((sum, cp) => 
        sum + cp.price, 0) / (product.competitorPrices.length || 1);

      if (priceStatusFilter === "Lower than competition" && product.currentPrice >= avgCompetitorPrice) {
        return false;
      }
      if (priceStatusFilter === "Higher than competition" && product.currentPrice <= avgCompetitorPrice) {
        return false;
      }
      if (priceStatusFilter === "Matching competition" && 
          Math.abs(product.currentPrice - avgCompetitorPrice) / avgCompetitorPrice > 0.01) {
        return false;
      }
    }

    return true;
  });

  // Pagination
  const indexOfLastProduct = currentPage * productsPerPage;
  const indexOfFirstProduct = indexOfLastProduct - productsPerPage;
  const currentProducts = filteredProducts.slice(indexOfFirstProduct, indexOfLastProduct);
  const totalPages = Math.ceil(filteredProducts.length / productsPerPage);

  // Handle price optimization for a single product
  const handleOptimizePrice = async (productId: number) => {
    try {
      await apiRequest('POST', `/api/apply-suggested-price/${productId}`, {});
      
      // Invalidate cache and refetch
      queryClient.invalidateQueries({ queryKey: ['/api/products-with-prices'] });
      onRefetch();
      
      toast({
        title: "Success",
        description: "Price has been successfully optimized!",
        variant: "success",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to optimize price. Please try again.",
        variant: "destructive",
      });
    }
  };

  // Render loading state
  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Products & Competitive Pricing</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {[...Array(5)].map((_, i) => (
              <Skeleton key={i} className="w-full h-16" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="border-b flex flex-col md:flex-row md:items-center md:justify-between">
        <CardTitle>Products & Competitive Pricing</CardTitle>
        <div className="flex items-center mt-2 md:mt-0 space-x-2">
          <Select value={categoryFilter} onValueChange={setCategoryFilter}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="All Categories" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="All Categories">All Categories</SelectItem>
              <SelectItem value="Electronics">Electronics</SelectItem>
              <SelectItem value="Home & Kitchen">Home & Kitchen</SelectItem>
              <SelectItem value="Toys & Games">Toys & Games</SelectItem>
            </SelectContent>
          </Select>
          
          <Select value={priceStatusFilter} onValueChange={setPriceStatusFilter}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="All Price Statuses" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="All Price Statuses">All Price Statuses</SelectItem>
              <SelectItem value="Lower than competition">Lower than competition</SelectItem>
              <SelectItem value="Higher than competition">Higher than competition</SelectItem>
              <SelectItem value="Matching competition">Matching competition</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Product</TableHead>
              <TableHead className="text-right">Your Price</TableHead>
              <TableHead className="text-right">Amazon</TableHead>
              <TableHead className="text-right">Walmart</TableHead>
              <TableHead className="text-right">Best Buy</TableHead>
              <TableHead className="text-right">Suggested Price</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {currentProducts.map(product => {
              // Organize competitor prices by competitor name
              const amazonPrice = product.competitorPrices.find(cp => cp.competitorName === "Amazon");
              const walmartPrice = product.competitorPrices.find(cp => cp.competitorName === "Walmart");
              const bestBuyPrice = product.competitorPrices.find(cp => cp.competitorName === "Best Buy");
              
              // Calculate price differences for display
              const calcPriceDiff = (competitorPrice?: number) => {
                if (!competitorPrice) return null;
                const diff = product.currentPrice - competitorPrice;
                if (Math.abs(diff) < 0.01) return "Matched";
                return diff > 0 ? `$${Math.abs(diff).toFixed(2)} higher` : `$${Math.abs(diff).toFixed(2)} margin`;
              };

              const amazonDiff = calcPriceDiff(amazonPrice?.price);
              const walmartDiff = calcPriceDiff(walmartPrice?.price);
              const bestBuyDiff = calcPriceDiff(bestBuyPrice?.price);
              
              // Determine margin for suggested price
              const margin = product.suggestedPrice 
                ? Math.round((product.suggestedPrice / (product.currentPrice * 0.7) - 1) * 100) 
                : 0;
              
              // Check if suggested price is same as current
              const noChangeNeeded = product.suggestedPrice 
                ? Math.abs(product.suggestedPrice - product.currentPrice) < 0.01 
                : true;

              return (
                <TableRow key={product.id}>
                  <TableCell>
                    <div className="flex items-center">
                      <img 
                        src={product.imageUrl || `https://source.unsplash.com/featured/?${encodeURIComponent(product.name)}`} 
                        alt={product.name} 
                        className="w-10 h-10 object-cover rounded mr-3" 
                      />
                      <div>
                        <p className="font-medium">{product.name}</p>
                        <p className="text-xs text-muted-foreground">{product.category}</p>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell className="text-right font-mono">${product.currentPrice.toFixed(2)}</TableCell>
                  <TableCell className="text-right">
                    {amazonPrice ? (
                      <div className="flex flex-col items-end">
                        <span className="font-mono">${amazonPrice.price.toFixed(2)}</span>
                        <span className={`text-xs mt-1 ${amazonDiff === "Matched" ? "text-muted-foreground" : amazonDiff?.includes("higher") ? "text-destructive" : "text-emerald-500"}`}>
                          {amazonDiff}
                        </span>
                      </div>
                    ) : <span className="text-muted-foreground">N/A</span>}
                  </TableCell>
                  <TableCell className="text-right">
                    {walmartPrice ? (
                      <div className="flex flex-col items-end">
                        <span className="font-mono">${walmartPrice.price.toFixed(2)}</span>
                        <span className={`text-xs mt-1 ${walmartDiff === "Matched" ? "text-muted-foreground" : walmartDiff?.includes("higher") ? "text-destructive" : "text-emerald-500"}`}>
                          {walmartDiff}
                        </span>
                      </div>
                    ) : <span className="text-muted-foreground">N/A</span>}
                  </TableCell>
                  <TableCell className="text-right">
                    {bestBuyPrice ? (
                      <div className="flex flex-col items-end">
                        <span className="font-mono">${bestBuyPrice.price.toFixed(2)}</span>
                        <span className={`text-xs mt-1 ${bestBuyDiff === "Matched" ? "text-muted-foreground" : bestBuyDiff?.includes("higher") ? "text-destructive" : "text-emerald-500"}`}>
                          {bestBuyDiff}
                        </span>
                      </div>
                    ) : <span className="text-muted-foreground">N/A</span>}
                  </TableCell>
                  <TableCell className="text-right">
                    {product.suggestedPrice ? (
                      <div className="flex flex-col items-end">
                        <span className="font-mono font-semibold text-blue-500">${product.suggestedPrice.toFixed(2)}</span>
                        {noChangeNeeded ? (
                          <span className="text-xs text-muted-foreground mt-1">No change</span>
                        ) : (
                          <span className="text-xs text-emerald-500 mt-1">+{margin}% margin</span>
                        )}
                      </div>
                    ) : <span className="text-muted-foreground">Calculating...</span>}
                  </TableCell>
                  <TableCell>
                    <div className="flex justify-end space-x-2">
                      <Button variant="ghost" size="icon" className="h-8 w-8 text-blue-500 bg-blue-50" title="View Details">
                        <Eye className="h-4 w-4" />
                      </Button>
                      {noChangeNeeded ? (
                        <Button disabled variant="ghost" size="icon" className="h-8 w-8 opacity-50 cursor-not-allowed" title="No optimization needed">
                          <Wand2 className="h-4 w-4" />
                        </Button>
                      ) : (
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="h-8 w-8 text-primary bg-primary/10" 
                          title="Optimize Price" 
                          onClick={() => handleOptimizePrice(product.id)}
                        >
                          <Wand2 className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </div>
      
      <div className="p-4 flex flex-col md:flex-row items-center justify-between text-sm">
        <div className="mb-3 md:mb-0">
          Showing {Math.min(indexOfFirstProduct + 1, filteredProducts.length)} to {Math.min(indexOfLastProduct, filteredProducts.length)} of {filteredProducts.length} products
        </div>
        {totalPages > 1 && (
          <div className="flex items-center space-x-2">
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
              disabled={currentPage === 1}
            >
              Previous
            </Button>
            {[...Array(totalPages)].map((_, i) => (
              <Button 
                key={i}
                variant={currentPage === i + 1 ? "default" : "outline"} 
                size="sm"
                onClick={() => setCurrentPage(i + 1)}
              >
                {i + 1}
              </Button>
            ))}
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
              disabled={currentPage === totalPages}
            >
              Next
            </Button>
          </div>
        )}
      </div>
    </Card>
  );
}
