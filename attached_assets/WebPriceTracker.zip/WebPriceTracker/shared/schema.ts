import { pgTable, text, serial, integer, numeric, timestamp, customType } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const productCategories = [
  'Electronics / Audio',
  'Electronics / Wearables',
  'Electronics / Headphones',
  'Electronics / Gaming',
  'Electronics / Computers',
  'Electronics / Smartphones',
  'Home & Kitchen',
  'Toys & Games'
];

// Products table definition
export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  category: text("category").notNull(),
  description: text("description"),
  currentPrice: numeric("current_price", { precision: 10, scale: 2 }).notNull(),
  suggestedPrice: numeric("suggested_price", { precision: 10, scale: 2 }),
  imageUrl: text("image_url"),
  sku: text("sku").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Competitors table definition
export const competitors = pgTable("competitors", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  website: text("website").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Competitor prices table definition
export const competitorPrices = pgTable("competitor_prices", {
  id: serial("id").primaryKey(),
  productId: integer("product_id").notNull().references(() => products.id),
  competitorId: integer("competitor_id").notNull().references(() => competitors.id),
  price: numeric("price", { precision: 10, scale: 2 }).notNull(),
  timestamp: timestamp("timestamp").defaultNow(),
});

// Price history table for tracking our prices over time
export const priceHistory = pgTable("price_history", {
  id: serial("id").primaryKey(),
  productId: integer("product_id").notNull().references(() => products.id),
  price: numeric("price", { precision: 10, scale: 2 }).notNull(),
  timestamp: timestamp("timestamp").defaultNow(),
});

// Schemas for inserts
export const insertProductSchema = createInsertSchema(products)
  .omit({ id: true, createdAt: true, updatedAt: true, suggestedPrice: true });

export const updateProductSchema = createInsertSchema(products)
  .partial()
  .omit({ id: true, createdAt: true, updatedAt: true });

export const insertCompetitorSchema = createInsertSchema(competitors)
  .omit({ id: true, createdAt: true });

export const insertCompetitorPriceSchema = createInsertSchema(competitorPrices)
  .omit({ id: true, timestamp: true });

export const insertPriceHistorySchema = createInsertSchema(priceHistory)
  .omit({ id: true, timestamp: true });

// Types
export type Product = typeof products.$inferSelect;
export type InsertProduct = z.infer<typeof insertProductSchema>;
export type UpdateProduct = z.infer<typeof updateProductSchema>;

export type Competitor = typeof competitors.$inferSelect;
export type InsertCompetitor = z.infer<typeof insertCompetitorSchema>;

export type CompetitorPrice = typeof competitorPrices.$inferSelect;
export type InsertCompetitorPrice = z.infer<typeof insertCompetitorPriceSchema>;

export type PriceHistory = typeof priceHistory.$inferSelect;
export type InsertPriceHistory = z.infer<typeof insertPriceHistorySchema>;

// Extended types for frontend use
export type ProductWithCompetitorPrices = Product & {
  competitorPrices: {
    competitorId: number;
    competitorName: string;
    price: number;
  }[];
};

export type PriceTrend = {
  date: string;
  yourPrice: number;
  competitorPrices: {
    competitorId: number;
    competitorName: string;
    price: number;
  }[];
};

// These are the default competitors used in the app
export const defaultCompetitors = [
  { id: 1, name: "Amazon", website: "https://www.amazon.com" },
  { id: 2, name: "Walmart", website: "https://www.walmart.com" },
  { id: 3, name: "Best Buy", website: "https://www.bestbuy.com" }
];

// These are the default products used in the app
export const defaultProducts = [
  {
    id: 1,
    name: "Apple AirPods Pro",
    category: "Electronics / Audio",
    description: "Active Noise Cancellation, Transparency mode, Adaptive EQ",
    currentPrice: 229.99,
    sku: "APP-001",
    imageUrl: "https://source.unsplash.com/featured/?airpods"
  },
  {
    id: 2,
    name: "Samsung Galaxy Watch 4",
    category: "Electronics / Wearables",
    description: "Health monitoring, fitness tracking, smart notifications",
    currentPrice: 199.99,
    sku: "SGW-001",
    imageUrl: "https://source.unsplash.com/featured/?galaxywatch"
  },
  {
    id: 3,
    name: "Sony WH-1000XM4",
    category: "Electronics / Headphones",
    description: "Industry-leading noise cancellation, 30-hour battery life",
    currentPrice: 349.99,
    sku: "SONY-001",
    imageUrl: "https://source.unsplash.com/featured/?sonyheadphones"
  },
  {
    id: 4,
    name: "Nintendo Switch",
    category: "Electronics / Gaming",
    description: "Hybrid gaming console for home and on-the-go play",
    currentPrice: 299.99,
    sku: "NINT-001",
    imageUrl: "https://source.unsplash.com/featured/?nintendoswitch"
  },
  {
    id: 5,
    name: "Bose QuietComfort 45",
    category: "Electronics / Headphones",
    description: "Premium noise cancelling headphones with high-fidelity audio",
    currentPrice: 329.00,
    sku: "BOSE-001",
    imageUrl: "https://source.unsplash.com/featured/?boseheadphones"
  },
  {
    id: 6,
    name: "LG OLED C1 Series TV - 55 inch",
    category: "Electronics / Televisions",
    description: "4K Smart OLED TV with NVIDIA G-SYNC and FreeSync Premium",
    currentPrice: 1299.99,
    sku: "LG-001",
    imageUrl: "https://source.unsplash.com/featured/?lgtv"
  },
  {
    id: 7,
    name: "KitchenAid Stand Mixer",
    category: "Home & Kitchen",
    description: "Professional 5 Plus Series 5 Quart Bowl-Lift Stand Mixer",
    currentPrice: 399.99,
    sku: "KA-001",
    imageUrl: "https://source.unsplash.com/featured/?kitchenaid"
  },
  {
    id: 8,
    name: "Dyson V11 Torque Drive",
    category: "Home & Kitchen",
    description: "Cordless Vacuum Cleaner with LCD Screen",
    currentPrice: 599.99,
    sku: "DYSON-001",
    imageUrl: "https://source.unsplash.com/featured/?dysonvacuum"
  }
];

// Default competitor prices (these would typically be fetched or scraped)
export const defaultCompetitorPrices = [
  // Amazon prices
  { productId: 1, competitorId: 1, price: 249.99 }, // AirPods Pro
  { productId: 2, competitorId: 1, price: 199.99 }, // Galaxy Watch
  { productId: 3, competitorId: 1, price: 348.00 }, // Sony WH-1000XM4
  { productId: 4, competitorId: 1, price: 299.99 }, // Nintendo Switch
  { productId: 5, competitorId: 1, price: 329.00 }, // Bose QuietComfort
  { productId: 6, competitorId: 1, price: 1296.99 }, // LG OLED
  { productId: 7, competitorId: 1, price: 379.99 }, // KitchenAid
  { productId: 8, competitorId: 1, price: 599.99 }, // Dyson V11
  
  // Walmart prices
  { productId: 1, competitorId: 2, price: 224.99 }, // AirPods Pro
  { productId: 2, competitorId: 2, price: 189.99 }, // Galaxy Watch
  { productId: 3, competitorId: 2, price: 349.99 }, // Sony WH-1000XM4
  { productId: 4, competitorId: 2, price: 299.99 }, // Nintendo Switch
  { productId: 5, competitorId: 2, price: 319.99 }, // Bose QuietComfort
  { productId: 6, competitorId: 2, price: 1249.99 }, // LG OLED
  { productId: 7, competitorId: 2, price: 389.99 }, // KitchenAid
  { productId: 8, competitorId: 2, price: 579.99 }, // Dyson V11
  
  // Best Buy prices
  { productId: 1, competitorId: 3, price: 229.99 }, // AirPods Pro
  { productId: 2, competitorId: 3, price: 209.99 }, // Galaxy Watch
  { productId: 3, competitorId: 3, price: 349.99 }, // Sony WH-1000XM4
  { productId: 4, competitorId: 3, price: 299.99 }, // Nintendo Switch
  { productId: 5, competitorId: 3, price: 329.99 }, // Bose QuietComfort
  { productId: 6, competitorId: 3, price: 1299.99 }, // LG OLED
  { productId: 7, competitorId: 3, price: 399.99 }, // KitchenAid
  { productId: 8, competitorId: 3, price: 599.99 }  // Dyson V11
];
